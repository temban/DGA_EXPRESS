<template>
  <LoginVue/>
</template>

<script>
import LoginVue from './views/Login.vue'

export default {
  name: 'App',
  components: {
    LoginVue
  }
}
</script>