<template>
    <div>
        <!-- Main Menu -->
        <div class="topbar" style="height: 80px;background: linear-gradient(90deg, #fff, blue);">
            <div class="container-fluid" style="margin-left:-30px;height: 160px;">
                <div class="row">
                    <div class="col-md-5 hidden-xs">
                        <div class="header1__logo">
                            <router-link :to="{ name: 'Home' }" class="header1__logo-img"></router-link>
                        </div>
                    </div>
                    <div class="col-md-7 text-right">
                        <ul>
                            <!-- Profile Menu -->
                            <li class="btn-group user-account">
                                <a href="javascript:;" class="btn dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <div class="user-content">
                                        <div class="user-name">{{infoUser.firstName+" "+infoUser.lastName}}</div>
                                        <div class="user-plan">DGA Employee</div>
                                    </div>
                                    <div class="avatar" style="border-radius:40px">
                                        <img src="@/assets/img/hotels/59710428.jpg" alt="profile" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href="/employeeProfil" class="animsition-link dropdown-item wave-effect"><i
                                                class="feather icon-user"></i> Profile</a></li>
                                    <li><a @click="singout" class="animsition-link dropdown-item wave-effect"><i
                                                class="feather icon-log-in"></i> Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <employeeSidebarVue />
    </div>
</template>
<script>
import employeeSidebarVue from './employeeSidebar.vue'
export default {
    name: "adminNavbar",
    components: {
        employeeSidebarVue,
    },
    data() {
        return {
            infoUser: {
                firstName:'',
                lastName:"",
                profileimgage:''
            }
        }
    },
    mounted() {
        this.infoUser = JSON.parse(localStorage.getItem("infoUser"))
        
    },
    methods: {
        singout() {
            localStorage.removeItem("access-token");
            localStorage.clear();
            window.location.href = "/";
        },
    },
}
</script>

<style>
</style>