<template>

<div>
 <div style="margin-left:60px;">
    <lognavVue/>
    </div>
<usersidebarVue/>
  <b-container>



<div class="form_wrapper">
  <div class="form_container">
    <div class="title_container">
      <h2>Announcement Details</h2>
    </div>
    <div class="row clearfix">
      <div class="">
        <form>
              <div class="row clearfix">
            <div class="col_half">
              <h6>Departure Date</h6>
              <div class="input_field"><span><i class="fa fa-calendar" aria-hidden="true" style="margin-top:-2px"></i></span>
                <input 
                 v-model="departuredate" type="text" name="name" placeholder="Departure Date" />
              </div>    
            </div>
            <div class="col_half">
                <h6>Arrival Date</h6>
              <div class="input_field"> <span><i class="fa fa-calendar" aria-hidden="true" style="margin-top:-2px"></i></span>
                <input v-model="arrivaldate" type="text" name="name" placeholder="Arrival Date" required />
              </div>
            </div>
          </div>
            <div class="row clearfix">
            <div class="col_half">
                <h6>Source Town</h6>
              <div class="input_field"> <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
                <input v-model="departuretown" type="text" name="name" placeholder="Source Town" />
              </div>
            </div>
            <div class="col_half">
                <h6>Destination Town</h6>
              <div class="input_field"> <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
                <input v-model="destinationtown" type="text" name="name" placeholder="Destination Town" required />
              </div>
            </div>
          </div>
          <div class="row clearfix">
              <div class="col_half">
                    <h6> Price per Kilo</h6>
              <div class="input_field"> <span><i class="fa fa-money" aria-hidden="true"></i></span>
                <input v-model="price" type="text" name="name" placeholder="Price per Kilo" required />
              </div>
            </div>
        
            <div class="col_half">
                <h6> Quantity</h6>
              <div class="input_field"> <span><i class="fa fa-balance-scale" aria-hidden="true"></i></span>
                <input v-model="quantity" type="text" name="name" placeholder="Quantity" required />
              </div>
            </div>
              
               <div class="input_field">
                <input  v-model="id" type="hidden" name="name" placeholder="Departure Date" />
              </div> 
          </div>
           <div  v-if="document" class="input_field checkbox_option">
            <input v-model="document" type="checkbox" id="cb3" onclick="javascript: return false;">
            <label for="cb3">Documents</label>
            </div>
            <div  v-if="computer" class="input_field checkbox_option">
            <input v-model="computer" type="checkbox" id="cb4" onclick="javascript: return false;">
    	 <label for="cb4">Computers</label>
            </div>
          <div class="input_field">
                <h6>Restriction</h6>
            <textarea v-model="restriction" name="name"  style="font-family:sans-serif;font-size:1.2em;width:100%" readonly></textarea>
          </div>



            






             <h2 style="text-align: center">Update Your Reservation</h2>

            <div class="row clearfix">
           
            <div class="col_half">
                <h6> Kilos Reserved</h6>
              <div class="input_field"> <span><i aria-hidden="true" class="fa fa fa-balance-scale"></i></span>
                <input style="padding-left:40px" v-bind="quantity" @change="() => { if(quantitykilo > quantity || quantitykilo < 1) { quantitykilo = 1 }}" v-model="quantitykilo" type="number" class="form-control" required />
              </div>
            </div>
               <div class="input_field">
                <input  v-model="id1" type="hidden" name="name" placeholder="Departure Date" />
                <input  v-model="annId" type="hidden" name="name" placeholder="Departure Date" />
              </div> 
              
          </div>
            <div  v-if="document" class="input_field checkbox_option">
            <input v-model="doc" type="checkbox" id="cb1">
            <label for="cb1">Do You Have Documents</label>
            </div>
            <div v-if="computer" class="input_field checkbox_option">
            <input  v-model="pc" type="checkbox" id="cb2">
    	 <label for="cb2">Do you Have a Computers</label>
            </div>

            <div class="input_field">
                <h6>Description</h6>
            <textarea v-model="desc" name="name"  style="font-family:sans-serif;font-size:1.2em;width:100%"></textarea>
          </div>
           <button @click="onSubmit" type="button" style=" display:flex;
                      align-items:center;
                      justify-content:center;" class="create">
        <i class="fa fa-plus" style="font-size:20px;color:white; margin-top:20px;margin-left:-22px"></i>
        <span style="font-size:20px; margin-left:-10px"> Update Reservation</span ></button> 

        </form>
      </div>
    </div>
  </div>
</div>
</b-container>
<footerVue />
</div>

</template>

<script>
import Swal from 'sweetalert2';
import footerVue from "@/components/footer.vue"
import usersidebarVue from "../components/usersidebar.vue";
import lognavVue from '../components/lognav.vue';
    export default {
    name: "EditAnnouncement",
       data() {
      return {
             id1: this.$route.params.id,
             annId:'',
        modalShow: false,
  departuredate: "",
  arrivaldate: "",
  departuretown: "",
  destinationtown: "",
  quantity: "",
  computer: null,
  restriction: "",
  document: null,
  price:"",
  name:'',

  doc: null,
  pc: null,
  desc: "",
  qtykilo: "",
  
    
      }
    }, 
       
    components:{
          lognavVue,
        usersidebarVue,
        footerVue
    },

   async created() {
var axios = require('axios');
var config = {
  method: 'get',
  url: 'http://46.105.36.240:3000/reservations/'+this.id1,
  headers: { 
    'Content-Type': 'application/json', 
    'Authorization': 'Bearer ' + localStorage.getItem('access-token')
     },
};

axios(config)
.then(res => {
    this.annId=res.data.announcementDto.id
        this.departuredate = res.data.announcementDto.departuredate;
        this.arrivaldate = res.data.announcementDto.arrivaldate;
        this.departuretown = res.data.announcementDto.departuretown;
        this.destinationtown = res.data.announcementDto.destinationtown;
        this.quantity = res.data.announcementDto.quantity;

        this.computer = res.data.announcementDto.computer;
        this.restriction = res.data.announcementDto.restriction;
        this.document = res.data.announcementDto.document;
        this.price = res.data.announcementDto.price;
        this.id = res.data.announcementDto.id;
 

 
        this.pc = res.data.computer;
        this.desc = res.data.description;
        this.doc = res.data.documents;
        this.qtykilo = res.data.quantitykilo;
        this.name = res.data.announcementDto.userDto.firstName +' '+ res.data.announcementDto.userDto.lastName ;

       

       
localStorage.setItem('annrevid', res.data.announcementDto.id);
localStorage.setItem('Annrev-departuredate', res.data.announcementDto.departuredate);
localStorage.setItem('Annrev-arrivaldate', res.data.announcementDto.arrivaldate);
localStorage.setItem('Annrev-departuretown', res.data.announcementDto.departuretown);
localStorage.setItem('Annrev-destinationtown', res.data.announcementDto.destinationtown);
        
localStorage.setItem('Annrev-restriction', res.data.announcementDto.restriction);
localStorage.setItem('Annrev-quantity', res.data.announcementDto.quantity);
localStorage.setItem('Annrev-price', res.data.announcementDto.price);
localStorage.setItem('Annrev-computer', res.data.announcementDto.computer);
localStorage.setItem('Annrev-document', res.data.announcementDto.document);

localStorage.setItem('Annrev-id', res.data.announcementDto.userDto.id);
localStorage.setItem('Annrev-firstName', res.data.announcementDto.userDto.firstName);
localStorage.setItem('Annrev-lastName', res.data.announcementDto.userDto.lastName);
localStorage.setItem('Annrev-email', res.data.announcementDto.userDto.email);
localStorage.setItem('Annrev-pseudo', res.data.announcementDto.userDto.pseudo);
localStorage.setItem('Annrev-id', res.data.announcementDto.userDto.id)



      console.log(JSON.stringify( res.data.date));  

        //localStorage.setItem('refresh-token', refreshtoken);
        //localStorage.setItem('access-token', accesstoken);
      })
.catch(function (error) {
     localStorage.clear()
        window.location.href = "/"
  console.log(error);
});

  },


 methods: {

  onSubmit(event){
  Swal.fire({
  title: 'Are you sure?',
  text: "Make Sure kilo entered is within range, if not it will initialise to 1 when send!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Update!'
}).then((result) => {
  if (result.isConfirmed) {
        event.preventDefault()
var axios = require('axios');
var data = JSON.stringify({

   "id":  this.id1,
  "description": this.desc,
  "documents": this.doc,
  "computer": this.pc,
  "status": "ENABLED",
  "quantitykilo": this.qtykilo,
  "userDto": {
     "id": localStorage.getItem('userId'),
    "firstName": localStorage.getItem('firstName'),
    "lastName": localStorage.getItem('lastName'),
    "pseudo": localStorage.getItem('pseudo'),
    "email": localStorage.getItem('email'),
    "roleDtos": [
      {
        "id": 2,
        "name": "ROLE_CLIENT"
      }
    ],
    "status": "ENABLED"
  },
 "announcementDto": {

      "id":  this.annId,
    "departuredate": localStorage.getItem('Annrev-departuredate') ,
    "arrivaldate": localStorage.getItem('Annrev-arrivaldate') ,
    "departuretown": localStorage.getItem('Annrev-departuretown') ,
    "destinationtown": localStorage.getItem('Annrev-destinationtown') ,
    "quantity": localStorage.getItem('Annrev-quantity') ,
    "computer":  localStorage.getItem('Annrev-computer') ,
    "restriction": localStorage.getItem('Annrev-restriction') ,
    "document": localStorage.getItem('Annrev-document') ,
    "status": "ENABLED",


     "cni": "string",
    "ticket": "string",
    "covidtest": "string",
    "price": localStorage.getItem('Annrev-price') ,
    "validation": true,
    "userDto": {
      "id":  localStorage.getItem('Annrev-id') ,
      "firstName": localStorage.getItem('Annrev-firstName') ,
      "lastName":localStorage.getItem('Annrev-lastName') ,
      "pseudo": localStorage.getItem('Annrev-pseudo') ,
      "email": localStorage.getItem('Annrev-email') ,
      "roleDtos": [
        {
          "id": 2,
          "name": "ROLE_CLIENT"
        }
      ],
      "status": "ENABLED"
    }
  }

});

var config = {
  method: 'put',
  url: 'http://46.105.36.240:3000/update/reseravtion',
  headers: { 
    'Content-Type': 'application/json', 
    'Authorization': 'Bearer '+ localStorage.getItem('access-token') },
  data : data
};

axios(config)
.then(function (response) {
  console.log(JSON.stringify(response.data));
   Swal.fire(
      'Success!',
      'Your Travel has been Created.',
      'success'
    )
   window.location.href = "/MyReservations"
})
.catch(function (error) {
        Swal.fire(
      'Failed!',
      'Something went wrong!.',
      'error'
    )
  console.log(error);
});
  
  }
})
}}
    }
</script>


<style lang="scss">

$yellow:#f5ba1a;
$black:#000000;
$grey:#cccccc;


.clearfix {
	&:after {
		content: "";
		display: block;
		clear: both;
		visibility: hidden;
		height: 0;
	}
}
.form_wrapper {
	background: rgb(255, 251, 241);
	width: 100%;
    margin-bottom:20px;
	max-width: 100%;
	box-sizing: border-box;
	padding: 25px;
	position: relative;
	z-index: 1;
	border-top: 5px solid $yellow;
	-webkit-box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
	-moz-box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
	box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
    -webkit-transform-origin: 50% 0%;
    transform-origin: 50% 0%;
    -webkit-transform: scale3d(1, 1, 1);
    transform: scale3d(1, 1, 1);
    -webkit-transition: none;
    transition: none;
    -webkit-animation: expand 0.8s 0.6s ease-out forwards;
    animation: expand 0.8s 0.6s ease-out forwards;
    opacity: 0;
	h2 {
		font-size: 1.5em;
		line-height: 1.5em;
		margin: 0;
	}
    	h6 {
		font-size: 1em;
		line-height: 1em;
		margin-: 0;
	}
	.title_container {
		text-align: center;
		padding-bottom: 15px;
	}
	h3 {
		font-size: 1.1em;
		font-weight: normal;
		line-height: 1.5em;
		margin: 0;
	}
    label {
        font-size: 12px;
    }
	.row {
		margin: 10px -15px;
		>div {
			padding: 0 15px;
			box-sizing: border-box;
		}
	}
	.col_half {
		width: 50%;
		float: left;
	}
	.input_field {
		position: relative;
		margin-bottom: 10px;
        -webkit-animation: bounce 0.6s ease-out;
  	     animation: bounce 0.6s ease-out;
		>span {
			position: absolute;
			left: 0;
			top: 0;
			color: #333;
			height: 100%;
			border-right: 1px solid $grey;
			text-align: center;
			width: 30px;
			>i {
			}
		}
	}
	.textarea_field {
		>span {
			>i {
			}
		}
	}
	input {
    &[type="text"], &[type="email"], &[type="password"] {
      width: 500px;
      padding: 8px 10px 9px 35px;
      height: 35px;
      border: 1px solid $grey;
      box-sizing: border-box;
      outline: none;
      -webkit-transition: all 0.30s ease-in-out;
      -moz-transition: all 0.30s ease-in-out;
      -ms-transition: all 0.30s ease-in-out;
      transition: all 0.30s ease-in-out;
    }
    &[type="text"]:hover, &[type="email"]:hover, &[type="password"]:hover {
      background: #f8f8f8;
    }
    &[type="text"]:focus, &[type="email"]:focus, &[type="password"]:focus {
      -webkit-box-shadow: 0 0 2px 1px rgb(255, 153, 0);
      -moz-box-shadow: 0 0 2px 1px rgb(255, 153, 0);
      box-shadow: 0 0 2px 1px rgb(255, 153, 0);
      border: 1px solid $yellow;
      background: #f7f7f7;
    }
    &[type="submit"] {
		background: $yellow;
		height: 35px;
		line-height: 35px;
		width: 100%;
		border: none;
		outline: none;
		cursor: pointer;
		color: #fff;
		font-size: 1.1em;
		margin-bottom: 10px;
		-webkit-transition: all 0.30s ease-in-out;
		-moz-transition: all 0.30s ease-in-out;
		-ms-transition: all 0.30s ease-in-out;
		transition: all 0.30s ease-in-out;
		&:hover {
			background: darken($yellow,7%);
		}
		&:focus {
			background: darken($yellow,7%);
		}
	}    
    &[type="checkbox"], &[type="radio"] {
      border: 0;
      clip: rect(0 0 0 0);
      height: 1px;
      margin: -1px;
      overflow: hidden;
      padding: 0;
      position: absolute;
      width: 1px;
    }
  }
}
.form_container {
	.row {
		.col_half.last {
			border-left: 1px solid $grey;
		}
	}
}
.checkbox_option{
    label{
        margin-right: 1em;
        position: relative;
        &:before {
          content: "";
          display: inline-block;
          width: 1.1em;
          height: 1.1em;
          margin-right: 0.5em;
          vertical-align: -2px;
          border: 2px solid $grey;
          padding: 0.12em;
          background-color: transparent;
          background-clip: content-box;
          transition: all 0.2s ease;
        }
        &:after {
          border-right: 2px solid $black;
          border-top: 2px solid $black;
          content: "";
          height: 20px;
          left: 2px;
          position: absolute;
          top: 7px;
          transform: scaleX(-1) rotate(135deg);
          transform-origin: left top;
          width: 7px;
          display: none;
        }
    }
    input {
    &:hover + label:before {
      border-color: $black;
    }
    &:checked + label {
      &:before {
        border-color: $black;
      }
      &:after {
        -moz-animation: check 0.8s ease 0s running;
        -webkit-animation: check 0.8s ease 0s running;
        animation: check 0.8s ease 0s running;
        display: block;
        width: 7px;
        height: 20px;
        border-color: $black;
      }
    }
  }
}
.radio_option {
  label {
      margin-right: 1em;
    &:before {
      content: "";
      display: inline-block;
      width: 0.8em;
      height: 0.8em;
      margin-right: 0.5em;
      border-radius: 100%;
      vertical-align: -3px;
      border: 2px solid $grey;
      padding: 0.15em;
      background-color: transparent;
      background-clip: content-box;
      transition: all 0.2s ease;
    }
  }
  input {
    &:hover + label:before {
      border-color: $black;
    }
    &:checked + label:before {
      background-color: $black;
      border-color: $black;
    }
  }
}
.credit {
	position: relative;
	z-index: 1;
	text-align: center;
	padding: 15px;
	color: $yellow;
	a {
		color: darken($yellow,7%);
	}
}
@-webkit-keyframes check {
  0% { height: 0; width: 0; }
  25% { height: 0; width: 7px; }
  50% { height: 20px; width: 7px; }
}

@keyframes check {
  0% { height: 0; width: 0; }
  25% { height: 0; width: 7px; }
  50% { height: 20px; width: 7px; }
}

@-webkit-keyframes expand { 
	0% { -webkit-transform: scale3d(1,0,1); opacity:0; }
	25% { -webkit-transform: scale3d(1,1.2,1); }
	50% { -webkit-transform: scale3d(1,0.85,1); }
	75% { -webkit-transform: scale3d(1,1.05,1); }
	100% { -webkit-transform: scale3d(1,1,1);  opacity:1; }
}

@keyframes expand { 
	0% { -webkit-transform: scale3d(1,0,1); transform: scale3d(1,0,1);  opacity:0; }
	25% { -webkit-transform: scale3d(1,1.2,1); transform: scale3d(1,1.2,1); }
	50% { -webkit-transform: scale3d(1,0.85,1); transform: scale3d(1,0.85,1); }
	75% { -webkit-transform: scale3d(1,1.05,1); transform: scale3d(1,1.05,1); }
	100% { -webkit-transform: scale3d(1,1,1); transform: scale3d(1,1,1);  opacity:1; }
}


@-webkit-keyframes bounce { 
	0% { -webkit-transform: translate3d(0,-25px,0); opacity:0; }
	25% { -webkit-transform: translate3d(0,10px,0); }
	50% { -webkit-transform: translate3d(0,-6px,0); }
	75% { -webkit-transform: translate3d(0,2px,0); }
	100% { -webkit-transform: translate3d(0,0,0); opacity: 1; }
}

@keyframes bounce { 
	0% { -webkit-transform: translate3d(0,-25px,0); transform: translate3d(0,-25px,0); opacity:0; }
	25% { -webkit-transform: translate3d(0,10px,0); transform: translate3d(0,10px,0); }
	50% { -webkit-transform: translate3d(0,-6px,0); transform: translate3d(0,-6px,0); }
	75% { -webkit-transform: translate3d(0,2px,0); transform: translate3d(0,2px,0); }
	100% { -webkit-transform: translate3d(0,0,0); transform: translate3d(0,0,0); opacity: 1; }
}
@media (max-width: 600px) {
	.form_wrapper {
		.col_half {
			width: 100%;
			float: none;
		}
	}
	.bottom_row {
		.col_half {
			width: 50%;
			float: left;
		}
	}
	.form_container {
		.row {
			.col_half.last {
				border-left: none;
			}
		}
	}
	.remember_me {
		padding-bottom: 20px;
	}
}

.create{
    
                display: inline-block;
                outline: 0;
                border: 0;
                cursor: pointer;
                will-change: box-shadow,transform;
                background: radial-gradient( 100% 100% at 100% 0%, #f0b07c 0%, #ff9100 100% );
                box-shadow: 0px 2px 4px rgb(247, 152, 43), 0px 7px 13px -3px rgba(241, 188, 12, 0.993), inset 0px -3px 0px rgba(241, 103, 61, 0.795);
                padding: 0 32px;
                border-radius: 6px;
                color: #fff;
                height: 48px;
                width:100%;
                float: center;
                font-size: 18px;
                text-shadow: 0 1px 0 rgba(241, 173, 94, 0.932);
                transition: box-shadow 0.15s ease,transform 0.15s ease;
                }
                .create:hover {
                    box-shadow: 0px 4px 8px rgb(255, 145, 1), 0px 7px 13px -3px rgb(45 35 66 / 30%), inset 0px -3px 0px #f37018;
                    transform: translateY(-2px);
                }
                .create:active{
                    box-shadow: inset 0px 3px 7px #ff7504;
                    transform: translateY(2px);
                }
</style>
