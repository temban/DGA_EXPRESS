<template>
  <div style="">
    <div style="margin-left: 60px">
      <lognavVue />
    </div>
    <usersidebarVue />

    <div>
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">My Reservation</h5>
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="">
                <div>
                  <div
                    class="container bootstrap snippets bootdey"
                    style="background: #d9dedf"
                  >
                    <section id="contact" class="gray-bg padding-top-bottom">
                      <div class="container bootstrap snippets bootdey">
                        <div class="row">
                          <form
                            id="Highlighted-form"
                            class="col-sm-6 col-sm-offset-3"
                          >
                            <div class="form-group">
                              <div
                                v-if="
                                  userId !== annDtouserDtoId && !comfirm &&
                                  annDtoStatus === 'ENABLED'
                                "
                                class="controls"
                              >
                                <input
                                  v-model="annDtouserDtoId"
                                  type="hidden"
                                />
                                <h6>Transaction ID</h6>
                                <input
                                  v-model="revId"
                                  id="contact-name"
                                  name="contactName"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  type="text"
                                  readonly
                                />
                                <i
                                  class="fa fa-copy"
                                  style="margin-bottom: -30px"
                                ></i>
                              </div>
                            </div>
                            <!-- End name input -->
                            <div class="form-group">
                              <div class="controls">
                                <h6>Owner</h6>
                                <input
                                  v-model="owner"
                                  id="contact-mail"
                                  name="email"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  type="text"
                                  readonly
                                />
                                <i class="fa fa-user"></i>
                              </div>
                            </div>
                            <div class="form-group">
                              <div class="controls">
                                <h6>Total Price</h6>
                                <input
                                  v-model="totalprice"
                                  id="contact-mail"
                                  name="email"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  type="text"
                                  readonly
                                />
                                <i class="fa fa-money"></i>
                              </div>
                            </div>
                            <div class="form-group">
                              <div class="controls">
                                <h6>Reservation Date</h6>
                                <input
                                  v-model="date"
                                  id="contact-mail"
                                  name="email"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  type="text"
                                  readonly
                                />
                                <i class="fa fa-calendar"></i>
                              </div>
                            </div>
                            <div class="form-group">
                              <div class="controls">
                                <h6>My Description</h6>
                                <textarea
                                  v-model="description"
                                  id="contact-message"
                                  name="comments"
                                  placeholder="Your message"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  rows="6"
                                  readonly
                                ></textarea>
                                <i class="fa fa-comment"></i>
                              </div>
                            </div>
                            <!-- End textarea -->
                            <hr />
                            <h5 class="modal-title" id="exampleModalLabel">
                              Announcement Info
                            </h5>

                            <!-- End name input -->
                            <div style="">
                              <img
                                :src="pic"
                                style="border-radius: 65px; margin-left: 100px"
                              />
                            </div>
                            <div class="form-group">
                              <div class="controls">
                                <h6>Traveller</h6>
                                <input
                                  v-model="annDtoFirstName"
                                  id="contact-name"
                                  name="contactName"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  type="text"
                                  readonly
                                />
                                <i
                                  class="fa fa-user"
                                  style="margin-bottom: -30"
                                ></i>
                              </div>
                            </div>
                            <!-- End name input -->

                            <div class="form-group">
                              <div class="controls">
                                <h6>Departure Date</h6>
                                <input
                                  v-model="annDtoDeparturedate"
                                  id="contact-name"
                                  name="contactName"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  type="text"
                                  readonly
                                />
                                <i
                                  class="fa fa-calendar"
                                  style="margin-bottom: -30px"
                                ></i>
                              </div>
                            </div>
                            <!-- End name input -->
                            <div class="form-group">
                              <div class="controls">
                                <h6>Arrival Date</h6>
                                <input
                                  v-model="annDtoArrivaldate"
                                  id="contact-name"
                                  name="contactName"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  data-new-placeholder="Your name"
                                  type="text"
                                  readonly
                                />
                                <i class="fa fa-calendar"></i>
                              </div>
                            </div>

                            <div class="form-group">
                              <div class="controls">
                                <h6>Announcement kilo Qty</h6>
                                <input
                                  v-model="annDtoQty"
                                  id="contact-mail"
                                  name="email"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  type="email"
                                  readonly
                                />
                                <i
                                  class="fa fa-balance-scale"
                                  aria-hidden="true"
                                ></i>
                              </div>

                              <div class="form-group1">
                                <div class="controls">
                                  <h6>Announcement price /kg</h6>
                                  <input
                                    v-model="annDtoPrice"
                                    id="contact-name"
                                    name="contactName"
                                    class="
                                      form-control
                                      requiredField
                                      Highlighted-label
                                    "
                                    type="text"
                                    readonly
                                  />
                                  <i class="fa fa-money"></i>
                                </div>
                              </div>
                            </div>
                            <!-- End email input -->
                            <div class="form-group">
                              <div class="controls">
                                <h6>Restriction</h6>
                                <textarea
                                  v-model="restriction"
                                  id="contact-message"
                                  name="comments"
                                  placeholder="Your message"
                                  class="
                                    form-control
                                    requiredField
                                    Highlighted-label
                                  "
                                  rows="6"
                                  readonly
                                ></textarea>
                                <i class="fa fa-comment"></i>
                              </div>
                            </div>
                            <!-- End textarea -->
                          </form>
                          <!-- End Highlighted-form -->
                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div>
      <div
        class="modal fade"
        id="exampleModal0"
        tabindex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Payment</h5>
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="">
                <div>
                  <div
                    class="container bootstrap snippets bootdey"
                    style="background: #d9dedf"
                  >
                    <section id="contact" class="gray-bg padding-top-bottom">
                      <div class="container bootstrap snippets bootdey">
                        <div class="row">

                          <form @submit.prevent="makePayment" id="searchthis" style="display: inline">
                            <div class="btn-wrapper">
                              <input
                                id="namanyay-search-box"
                                size="40"
                                type="text"
                                placeholder="Transaction Code! "
                                 v-model.number="amount"
                              />
                              <input
                                id="namanyay-search-btn"
                                value="pay"
                                type="submit"
                              />
                            </div>
                              
                            </form>

                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div style="margin: 30px 0 38px 550px" v-if="loading" class="loader"></div>
    <div class="container">
      <b-container
        style="margin-left: 32px; margin-bottom: 30px; background-color: white"
      >
        <!--<h3 class="mt-2 mb-3 float-left text-primary">My Travel Reservations</h3>
     <button
          @click="createAnn()"
          style="display: flex; align-items: center; justify-content: left"
          class="create"
        >
          <i
            class="fa fa-plus"
            style="
              font-size: 20px;
              color: white;
              margin-top: 20px;
              margin-left: -22px;
            "
          ></i>
          <span style="font-size: 20px; margin-left: -10px">New Travel</span>
        </button>-->

        <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">Traveler</th>
              <th scope="col">Source</th>
              <th scope="col">Destination</th>
              <th scope="col">Doc</th>
              <th scope="col">Reserved Qty</th>
              <th scope="col">Computer</th>
              <th scope="col">Status</th>

              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody style="text-transform: capitalize">
            <tr v-for="user in users" :key="user.id">
              <a v-if="user.announcementDto.profileimgage !== ''"
               
              >
              <img
                   :src="
                  'http://46.105.36.240:3000/' +
                  user.announcementDto.userDto.profileimgage
                "
                  style="width: 60px; height: 60px; border-radius: 30px"
                />
              </a>
              <a v-else href="/userDashboard">
                <img
                  src="@/assets/img/hotels/59710428.png"
                  style="width: 60px; height: 60px; border-radius: 30px"
                />
              </a>

              <td>{{ user.announcementDto.departuretown }}</td>
              <td>{{ user.announcementDto.destinationtown }}</td>
              <td v-if="user.documents">
                <i class="fa fa-check" style="font-size: 25px; color: lime"></i>
              </td>
              <td v-else>
                <i class="fa fa-remove" style="font-size: 25px; color: red"></i>
              </td>
              <td>{{ user.quantitykilo }}</td>
              <td v-if="user.computer">
                <i class="fa fa-check" style="font-size: 25px; color: lime"></i>
              </td>
              <td v-else>
                <i class="fa fa-remove" style="font-size: 25px; color: red"></i>
              </td>
              <td v-if="userId !== user.userDto.id && user.confirm">
                <span class="badge badge-success font-weight-100"
                  >Confirmed</span
                >
              </td>
              <td v-else-if="userId === user.userDto.id && user.confirm">
                <a
                  type="submit"
                  name="learn"
                  value="myimage"
                  style="border-radius: 30px"
                  data-target="#exampleModal0"
                  data-toggle="modal"
                >
                  <img
                    src="@/assets/img/hotels/pay.jpg"
                    class="rounded-circle img-fluid"
                    style="
                      image-resolution: 3000000dpi;
                      background-color: #000;
                      background-position: center;
                      background-size: cover;
                      background-repeat: no-repeat;
                      max-width: 100%;
                      max-height: 100%;
                      height: 60px;
                      width: 55px;
                      margin-bottom: -10px;
                      margin-top: -10px;
                      border: 2px solid black;
                    "
                  />
                </a>
              </td>
              <td v-else>
                <span class="badge badge-warning font-weight-100"
                  >Pending...</span
                >
              </td>
              <td>
                <form>
                  <!-- <button style="height:45px; width:40px;  margin-right:5px;" v-on:click="deleteUser(user.id)" type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash" style="font-size:20px"></i></button>
              -->
                  <button
                    v-if="user.announcementDto.status === 'ENABLED'"
                    v-on:click="view(user.id)"
                    data-target="#exampleModal"
                    data-toggle="modal"
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-info mr-1"
                  >
                    <i class="fa fa-eye" style="font-size: 20px"></i>
                  </button>
                  <button
                    v-else-if="
                      user.announcementDto.status === 'DISABLED' &&
                      user.status === 'DISABLED'
                    "
                    v-on:click="lockedRev()"
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-danger mr-1"
                  >
                    <i class="fa fa-trash" style="font-size: 20px"></i>
                  </button>
                  <button
                    v-on:click="lockedAnn()"
                    v-else
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-danger mr-1"
                  >
                    <i class="fas fa-lock" style="font-size: 20px"></i>
                  </button>

                  <router-link
                    v-if="
                      userId === user.userDto.id &&
                      user.announcementDto.status === 'ENABLED' &&
                      !user.confirm
                    "
                    class="btn btn-sm btn-info mr-1"
                    :to="{ name: 'EditReservation', params: { id: user.id } }"
                    style="height: 40px; width: 35px"
                    ><i class="fa fa-pencil" style="font-size: 20px"></i
                  ></router-link>
                  <button
                    v-else-if="
                      user.announcementDto.status === 'DISABLED' &&
                      user.status === 'DISABLED'
                    "
                    v-on:click="lockedRev()"
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-danger mr-1"
                  >
                    <i class="fa fa-trash" style="font-size: 20px"></i>
                  </button>
                  <button
                    v-on:click="lockedAnn()"
                    v-else
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-danger mr-1"
                  >
                    <i
                      class="fas fa-user-lock"
                      style="font-size: 18px; margin-right: 5px"
                    ></i>
                  </button>

                  <button
                    v-if="
                      userId === user.userDto.id &&
                      user.announcementDto.status === 'ENABLED' &&
                      user.status === 'ENABLED'
                    "
                    v-on:click="chatStorDataMyRevReceiver2(user.id)"
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-info mr-1"
                  >
                    <i
                      class="fa fa-commenting"
                      aria-hidden="true"
                      style="font-size: 20px"
                    ></i>
                  </button>
                  <button
                    v-else-if="
                      userId === user.announcementDto.userDto.id &&
                      user.announcementDto.status === 'ENABLED' &&
                      user.status === 'ENABLED'
                    "
                    v-on:click="chatStorDataMyAnnReceiver1(user.id)"
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-info mr-1"
                  >
                    <i
                      class="fa fa-commenting"
                      aria-hidden="true"
                      style="font-size: 20px"
                    ></i>
                  </button>
                  <button
                    v-on:click="lockedAnn()"
                    v-else
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-danger mr-1"
                  >
                    <i
                      class="fas fa-user-lock"
                      style="font-size: 18px; margin-right: 5px"
                    ></i>
                  </button>
                  <button
                    v-if="
                      userId !== user.userDto.id &&
                      user.announcementDto.status === 'ENABLED' &&
                      user.status === 'ENABLED' &&
                      !user.confirm
                    "
                    type="button"
                    v-on:click="confirmReservation(user.id)"
                    style="height: 40px; width: 35px"
                    class="btn btn-sm btn-success mr-1"
                  >
                    <i class="fa fa-check" style="font-size: 20px"></i>
                  </button>
                  <button
                    v-else
                    v-on:click="lockedRev()"
                    style="height: 40px; width: 35px; margin-right: 5px"
                    type="button"
                    class="btn btn-sm btn-danger mr-1"
                  >
                    <i
                      class="fas fa-user-lock"
                      style="font-size: 18px; margin-right: 5px"
                    ></i>
                  </button>

                  <!--
            <button v-if="userId!==user.announcementDto.id && user.announcementDto.status==='ENABLED' " style="height:45px; width:40px;  margin-right:5px;" type="button" class="btn btn-sm btn-info mr-1">
                  	<i class="far fa-check-circle" style="font-size:20px"></i>
                  </button>
                    <button  v-on:click="locked()"  v-else-if="serId!==user.announcementDto.id && user.announcementDto.status==='ENABLED' " style="height:45px; width:40px;  margin-right:5px;" type="button" class="btn btn-sm btn-danger mr-1">
                  	<i class="far fa-check-clock" style="font-size:20px"></i>
                  </button>  
                  <button  v-on:click="locked()"  v-else style="height:45px; width:40px;  margin-right:5px;" type="button" class="btn btn-sm btn-danger mr-1">
                  	<i class="fas fa-user-lock" style="font-size:20px"></i>
                  </button> 
                  --->
                </form>
              </td>
            </tr>
          </tbody>
        </table>
      </b-container>
      <!-- Fim tabela -->
    </div>
    <footerVue />
  </div>
</template>

<script>
import Swal from "sweetalert2";
import footerVue from "@/components/footer.vue";
import lognavVue from "../components/lognav.vue";
import usersidebarVue from "../components/usersidebar.vue";
export default {
  name: "MyReservations",
  data() {
    return {
      amount: 200,
      loading: true,
      users: [],
      userId: localStorage.getItem("userId"),
      id: "",
      date: "",
      description: "",
      annDtoDeparturedate: "",
      annDtoArrivaldate: "",
      annDtoFirstName: "",
      annDtoQty: "",
      restriction: "",
      annDtoPrice: "",
      annDtoid: "",
      annDtoStatus: "",
      annDtouserDtoId: "",
      profileimgage: "",
      totalprice: "",
      pic: "",
      owner: "",
      track:"",
      confirm:'',
      revId:""
    };
  },
  components: {
    lognavVue,
    usersidebarVue,
    footerVue,
  },

  async created() {
    var axios = require("axios");

    var config = {
      method: "get",
      url:
        "http://46.105.36.240:3000/user/" +
        localStorage.getItem("userId") +
        "/reservations",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("access-token"),
      },
    };

    axios(config)
      .then((res) => {
        this.users = res.data;
        this.loading = false;
      })
      .catch(function (error) {
        this.loading = false;
        Swal.fire({
          icon: "warning",
          title: "Oops...No Reservation found!",
        });
        console.log(error);
      });
  },
  methods: {
 
    makePayment() {
      this.$launchFlutterwave({
        tx_ref: Date.now(),
        amount: this.amount,
        currency: "XAF",
        payment_options: "card,mobilemoney,ussd",
             customer: {
          email: localStorage.getItem('email'),
          phonenumber:localStorage.getItem('tel'),
          name: localStorage.getItem('firstName') +" "+ localStorage.getItem('lastName'),
        },
        callback: function (data) {
          // specified callback function
          console.log(data);
        },
        customizations: {
          title: "DGA Expreess",
          description: "Courier Service Payment",
          logo: "https://assets.piedpiper.com/logo.png",
        },
      });
    },
    confirmReservation(id) {
      Swal.fire({
        title: "Confirm Travel",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Save",
        denyButtonText: `Don't save`,
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          var axios = require("axios");
          var config = {
            method: "get",
            url: "http://46.105.36.240:3000/reservations/" + id,
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + localStorage.getItem("access-token"),
            },
          };

          axios(config)
            .then((res) => {
              res.data.confirm = true;
              var data0 = JSON.stringify(res.data);
              var config0 = {
                method: "put",
                url: "http://46.105.36.240:3000/update/reseravtion",
                headers: {
                  "Content-Type": "application/json",
                  Authorization:
                    "Bearer " + localStorage.getItem("access-token"),
                },
                data: data0,
              };

              axios(config0)
                .then(function (response) {
                  console.log(response);
                  window.location.reload();
                })
                .catch(function (error) {
                  console.log(error);
                  Swal.fire("Failed!", "Something went wrong!.", "error");
                });

              //localStorage.setItem('refresh-token', refreshtoken);
              //localStorage.setItem('access-token', accesstoken);
            })
            .catch(function (error) {
              console.log(error);
            });

          /*var axios = require('axios');
var data = JSON.stringify(
  {
    "id": this.id,
   "departuredate": this.departuredate,
  "arrivaldate": this.arrivaldate,
  "departuretown": this.departuretown,
  "destinationtown": this.destinationtown,
  "quantity": this.quantity,
  "computer": this.computer,
  "restriction": this.restriction,
  "document": this.document,
  "status": "ENABLED",
  "cni": this.cni,
  "ticket": this.ticket,
  "covidtest": this.covidtest,
  "price": this.price,
  "validation": true,
  "userDto": {
    "id": this.userDtoId,
    "firstName": this.firstName,
    "lastName": this.lastName,
    "pseudo": this.pseudo,
    "email": this.email,
    "roleDtos": [
      {
        "id": 2,
        "name": "ROLE_CLIENT"
      }
    ],
    "status": "ENABLED"
    }
  });

var config = {
  method: 'put',
  url: 'http://46.105.36.240:3000/update/announcement',
  headers: { 
    'Content-Type': 'application/json', 
    'Authorization': 'Bearer '+ localStorage.getItem('access-token') },
  data : data
};

axios(config)
.then(function (response) {
  
      console.log(JSON.stringify(response.data.id));    
  console.log(JSON.stringify(response.data.departuredate));
    console.log(JSON.stringify(response.data.arrivaldate));
  console.log(JSON.stringify(response.data.departuretown));
  console.log(JSON.stringify(response.data.destinationtown));
    window.location.href = "/MyAnnouncements"
})
.catch(function (error) {
  console.log(error);
   Swal.fire(
      'Failed!',
      'Something went wrong!.',
      'error'
    )
    
});*/
          Swal.fire("Saved!", "", "success");
        } else if (result.isDenied) {
          Swal.fire("Changes are not saved", "", "info");
        }
      });
    },

    lockedAnn() {
      Swal.fire({
        icon: "error",
        title: "Oops... Announcement Has Been Deletet!",
        text: "Contact DGA Client Service for more Info!",
        footer: '<a href="">Why do I have this issue?</a>',
      });
    },

    lockedRev() {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Oops... Reservation Has Been Deletet!",
        footer: '<a href="">Why do I have this issue?</a>',
      });
    },

    chatStorDataMyAnnReceiver1(id) {
      var axios = require("axios");
      var config = {
        method: "get",
        url: "http://46.105.36.240:3000/reservations/" + id,
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("access-token"),
        },
      };

      axios(config)
        .then((res) => {
          this.annDtoStatus = res.data.announcementDto.status;
          this.date = res.data.date;
          this.description = res.data.description;
          this.annDtoid = res.data.announcementDto.id;
          this.annDtoDeparturedate = res.data.announcementDto.departuredate;
          this.annDtoArrivaldate = res.data.announcementDto.arrivaldate;
          this.annDtoFirstName = res.data.announcementDto.userDto.firstName;
          this.annDtoQty = res.data.announcementDto.quantity;
          this.restriction = res.data.announcementDto.restriction;
          this.annDtoPrice = res.data.announcementDto.price;
          this.annDtouserDtoId = res.data.announcementDto.userDto.id;

          localStorage.setItem("Rev-id", res.data.id);
          localStorage.setItem("Rev-description", res.data.description);
          localStorage.setItem("Rev-documents", res.data.documents);
          localStorage.setItem("Rev-computer", res.data.computer);
          localStorage.setItem("Rev-quantitykilo", res.data.quantitykilo);
          localStorage.setItem("Rev-date", res.data.date);
          localStorage.setItem("Rev-totalprice", res.data.totalprice);

          localStorage.setItem("AnnRev-id", res.data.announcementDto.id);
          localStorage.setItem(
            "AnnRev-departuredate",
            res.data.announcementDto.departuredate
          );
          localStorage.setItem(
            "AnnRev-arrivaldate",
            res.data.announcementDto.arrivaldate
          );
          localStorage.setItem(
            "AnnRev-departuretown",
            res.data.announcementDto.departuretown
          );
          localStorage.setItem(
            "AnnRev-destinationtown",
            res.data.announcementDto.destinationtown
          );
          localStorage.setItem(
            "AnnRev-restriction",
            res.data.announcementDto.restriction
          );
          localStorage.setItem(
            "AnnRev-quantity",
            res.data.announcementDto.quantity
          );
          localStorage.setItem("AnnRev-price", res.data.announcementDto.price);
          localStorage.setItem(
            "AnnRev-computer",
            res.data.announcementDto.computer
          );
          localStorage.setItem(
            "AnnRev-document",
            res.data.announcementDto.document
          );

          localStorage.setItem("receiver-id", res.data.userDto.id);
          localStorage.setItem(
            "receiver-firstName",
            res.data.userDto.firstName
          );
          localStorage.setItem("receiver-lastName", res.data.userDto.lastName);
          localStorage.setItem("receiver-email", res.data.userDto.email);
          localStorage.setItem("receiver-pseudo", res.data.userDto.pseudo);
          localStorage.setItem(
            "receiver-prifil-image",
            res.data.userDto.profileimgage
          );

          window.location.href = "/chatRoomMyRev";
          console.log(
            JSON.stringify("blaise" + res.data.announcementDto.status)
          );
          console.log(
            JSON.stringify("blaise" + res.data.announcementDto.status)
          );
          console.log(
            JSON.stringify("blaise" + res.data.announcementDto.status)
          );
          //localStorage.setItem('refresh-token', refreshtoken);
          //localStorage.setItem('access-token', accesstoken);
        })
        .catch(function (error) {
          console.log(error);
        });
    },

    chatStorDataMyRevReceiver2(id) {
      var axios = require("axios");
      var config = {
        method: "get",
        url: "http://46.105.36.240:3000/reservations/" + id,
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("access-token"),
        },
      };

      axios(config)
        .then((res) => {
          this.annDtoStatus = res.data.announcementDto.status;
          this.date = res.data.date;
          this.description = res.data.description;
          this.annDtoid = res.data.announcementDto.id;
          this.annDtoDeparturedate = res.data.announcementDto.departuredate;
          this.annDtoArrivaldate = res.data.announcementDto.arrivaldate;
          this.annDtoFirstName = res.data.announcementDto.userDto.firstName;
          this.annDtoQty = res.data.announcementDto.quantity;
          this.restriction = res.data.announcementDto.restriction;
          this.annDtoPrice = res.data.announcementDto.price;
          this.annDtouserDtoId = res.data.announcementDto.userDto.id;

          localStorage.setItem("Rev-id", res.data.id);
          localStorage.setItem("Rev-description", res.data.description);
          localStorage.setItem("Rev-documents", res.data.documents);
          localStorage.setItem("Rev-computer", res.data.computer);
          localStorage.setItem("Rev-quantitykilo", res.data.quantitykilo);
          localStorage.setItem("Rev-date", res.data.date);
          localStorage.setItem("Rev-totalprice", res.data.totalprice);

          localStorage.setItem("AnnRev-id", res.data.announcementDto.id);
          localStorage.setItem(
            "AnnRev-departuredate",
            res.data.announcementDto.departuredate
          );
          localStorage.setItem(
            "AnnRev-arrivaldate",
            res.data.announcementDto.arrivaldate
          );
          localStorage.setItem(
            "AnnRev-departuretown",
            res.data.announcementDto.departuretown
          );
          localStorage.setItem(
            "AnnRev-destinationtown",
            res.data.announcementDto.destinationtown
          );
          localStorage.setItem(
            "AnnRev-restriction",
            res.data.announcementDto.restriction
          );
          localStorage.setItem(
            "AnnRev-quantity",
            res.data.announcementDto.quantity
          );
          localStorage.setItem("AnnRev-price", res.data.announcementDto.price);
          localStorage.setItem(
            "AnnRev-computer",
            res.data.announcementDto.computer
          );
          localStorage.setItem(
            "AnnRev-document",
            res.data.announcementDto.document
          );

          localStorage.setItem(
            "receiver-id",
            res.data.announcementDto.userDto.id
          );
          localStorage.setItem(
            "receiver-firstName",
            res.data.announcementDto.userDto.firstName
          );
          localStorage.setItem(
            "receiver-lastName",
            res.data.announcementDto.userDto.lastName
          );
          localStorage.setItem(
            "receiver-email",
            res.data.announcementDto.userDto.email
          );
          localStorage.setItem(
            "receiver-pseudo",
            res.data.announcementDto.userDto.pseudo
          );
          localStorage.setItem(
            "receiver-prifil-image",
            res.data.announcementDto.userDto.profileimgage
          );
          window.location.href = "/chatRoomMyRev";
          console.log(
            JSON.stringify("blaise" + res.data.announcementDto.status)
          );
          //localStorage.setItem('refresh-token', refreshtoken);
          //localStorage.setItem('access-token', accesstoken);
        })
        .catch(function (error) {
          console.log(error);
        });
    },

    view(id) {
      var axios = require("axios");
      var config = {
        method: "get",
        url: "http://46.105.36.240:3000/reservations/" + id,
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("access-token"),
        },
      };

      axios(config)
        .then((res) => {
            this.revId = res.data.id
            this.confirm = res.data.confirm
            this.track =  res.data.track;
          this.owner =
            res.data.userDto.firstName + "  " + res.data.userDto.lastName;
          this.annDtoStatus = res.data.announcementDto.status;
          this.date = res.data.date;
          this.description = res.data.description;
          this.annDtoid = res.data.announcementDto.id;
          this.annDtoDeparturedate = res.data.announcementDto.departuredate;
          this.annDtoArrivaldate = res.data.announcementDto.arrivaldate;
          this.annDtoFirstName =
            res.data.announcementDto.userDto.firstName +
            "  " +
            res.data.announcementDto.userDto.lastName;
          this.annDtoQty = res.data.announcementDto.quantity;
          this.restriction = res.data.announcementDto.restriction;
          this.annDtoPrice = res.data.announcementDto.price;
          this.annDtouserDtoId = res.data.announcementDto.userDto.id;
          this.profileimgage = res.data.announcementDto.userDto.profileimgage;
          this.totalprice = res.data.totalprice;
          this.pic = "http://46.105.36.240:3000/" + this.profileimgage;
          //localStorage.setItem('refresh-token', refreshtoken);
          //localStorage.setItem('access-token', accesstoken);
        })
        .catch(function (error) {
          console.log(error);
          localStorage.clear();
          window.location.href = "/";
        });
    },

    async deleteUser(id) {
      var axios = require("axios");

      var config = {
        method: "delete",
        url: "http://46.105.36.240:3000/user/" + id + "/reservations",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("access-token"),
        },
      };

      axios(config)
        .then(function (response) {
          console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
          localStorage.clear();
          window.location.href = "/";
          console.log(error);
        });
    },
  },
};
</script>

<style scoped>

.h6 {
  font-size: 18px;
  font-weight: 600;
}

.contact-item .icon {
  display: block;
  font-size: 48px;
  color: #75e1f7;
  text-shadow: -2px 2px 0 rgba(0, 0, 0, 0.1);
  -webkit-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}

.contact-item .icon:hover {
  color: #d9dedf;
  -webkit-transform: scale(1.3) translateY(-10px);
  transform: scale(1.3) translateY(-10px);
}

.bl_form {
}

.bl_form input {
  background: rgba(255, 255, 255, 0.1);
  box-shadow: 0 4px 0px rgba(0, 0, 0, 0.2);
  border: none;
  color: white;
  border-radius: 5px;
  font-size: 16px;
  outline: none;
}

.lb_wrap .lb_label.top,
.lb_wrap .lb_label.bottom {
  left: 66px !important;
}

.lb_wrap .lb_label.left {
  left: 0;
}

.lb_label {
  font-size: 18px;
  font-weight: 400;
  color: rgb(0, 0, 0);
}

.no-placeholder .lb_label {
  display: none;
}

.lb_label.active {
  color: #aaa;
}

#Highlighted-form .form-group label {
  display: none;
  font-size: 18px;
  font-weight: 100;
  text-transform: uppercase;
}

#Highlighted-form.no-placeholder .form-group label {
  display: block;
}

#Highlighted-form .controls {
  padding: 0;
  margin-top: 10px;
}

#Highlighted-form.no-placeholder .controls {
  margin-top: 0;
}

#Highlighted-form .form-control {
  display: inline;
  width: 400px;
  background: #fff;
  border: none;
  border-radius: 5px;
  outline: none;
  box-shadow: 0 4px 0 rgba(0, 0, 0, 0.05);
  height: 40px;
  font-size: 18px;
  color: rgb(0, 0, 0);
  font-weight: 400;
  padding-left: 54px;
}

#Highlighted-form .form-group.half-width {
  width: 40%;
  float: left;
}

#Highlighted-form .form-group {
  position: relative;
}

#Highlighted-form .form-group [class*="fa"] {
  display: block;
  width: 45px;
  position: absolute;
  top: 0;
  left: 5px;
  margin-top: 31px;
  color: rgb(255, 115, 0);
  font-size: 24px;
  line-height: 52px;
  text-align: center;
  font-weight: 300;
  -webkit-transition: color 0.3s ease-out;
  transition: color 0.3s ease-out;
}
#Highlighted-form .form-group1 [class*="fa"] {
  display: block;
  width: 45px;
  position: absolute;
  top: 0;
  left: 5px;
  margin-top: 110px;
  color: rgb(255, 115, 0);
  font-size: 24px;
  line-height: 52px;
  text-align: center;
  font-weight: 300;
  -webkit-transition: color 0.3s ease-out;
  transition: color 0.3s ease-out;
}
#Highlighted-form .form-group [class*="fa"].active {
  color: #ccc;
}

#Highlighted-form.no-placeholder .form-group [class*="fa"] {
  top: 10px;
}

#Highlighted-form textarea.form-control {
  height: 100px;
  width: 400px;
  min-width: 100%;
  font-size: 18px;
  font-weight: 400;
  line-height: 24px;
  padding-top: 14px;
  vertical-align: top;
}

#Highlighted-form .form-control:focus {
  outline: none;
  box-shadow: 0 4px 0 rgba(0, 0, 0, 0.05);
}

#Highlighted-form .error-message {
  padding: 5px 0;
  position: absolute;
  top: -35px;
  right: 0;
  font-size: 15px;
  line-height: 24px;
  font-weight: 400;
  color: #ff3345;
  z-index: 10;
}

#Highlighted-form.no-placeholder .error-message {
  top: 0;
}
.create {
  display: inline-block;
  outline: 0;
  border: 0;
  cursor: pointer;
  will-change: box-shadow, transform;
  background: radial-gradient(100% 100% at 100% 0%, #f0b07c 0%, #ff9100 100%);
  box-shadow: 0px 2px 4px rgb(247, 152, 43),
    0px 7px 13px -3px rgba(241, 188, 12, 0.993),
    inset 0px -3px 0px rgba(241, 103, 61, 0.795);
  padding: 0 32px;
  border-radius: 6px;
  color: #fff;
  height: 58px;
  width: 20%;
  float: right;
  margin: 10px 0 10px 0;
  font-size: 18px;
  text-shadow: 0 1px 0 rgba(241, 173, 94, 0.932);
  transition: box-shadow 0.15s ease, transform 0.15s ease;
}
.create:hover {
  box-shadow: 0px 4px 8px rgb(255, 145, 1),
    0px 7px 13px -3px rgb(45 35 66 / 30%), inset 0px -3px 0px #f37018;
  transform: translateY(-2px);
}
.create:active {
  box-shadow: inset 0px 3px 7px #ff7504;
  transform: translateY(2px);
}

.h6 {
  font-size: 18px;
  font-weight: 600;
}
</style>
