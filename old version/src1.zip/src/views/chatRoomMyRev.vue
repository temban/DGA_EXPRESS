<template>
  <div>
    

<div style="height:10px">
<div class="card" >
					<div class="py-2 px-4 border-bottom d-none d-lg-block">
						<div class="d-flex align-items-center py-1">
							<img :src="'http://46.105.36.240:3000/'+ profileimgage"
                style="width: 90px;height:90px;border-radius:55px" />
							<div class="flex-grow-1 pl-4">
								<h3  style="text-transform: capitalize"><strong>{{firstName + "   "+lastName}}</strong></h3>
								<h5  style="text-transform: capitalize">From<em>{{" "+departuretown+" " }}</em>To<em>{{ " "+destinationtown}}</em></h5>
							</div>
							<div>
                                <router-link :to="{name: 'MyReservations'}" class="btn btn-light border btn-lg mr-3 px-3">
                                      <i class="fa fa-arrow-circle-left" style="font-size: 25px; color: red"></i>
                                </router-link>
								<router-link  :to="{name: 'Announcements'}" class="btn btn-primary btn-lg mr-1 px-3">
                                      <i class="fa fa-plane" style="font-size: 25px; color: white"></i>
                                </router-link>
								<router-link :to="{name: 'MarketPlace'}" class="btn btn-info btn-lg mr-1 px-3 d-none d-md-inline-block">
                                      <i class="fa fa-home" style="font-size: 25px; color: white"></i>
                                </router-link>
								
							</div>
						</div>
					</div>

					<div class="position-relative"  >
						<div class="chat-messages p-4"  >
                           <tr v-for="user in users" :key="user.id" >
     
                           <div class="chat-message-right pb-4"  v-if="user.sendermessage.id===userId">
								<div>
           <img :src="'http://46.105.36.240:3000/'+ user.sendermessage.profileimgage"
                style="width: 70px;height:70px;border-radius:55px" />
                                     
                                     <div  >{{user.date.slice(7, 22)}}</div>
                                     <div  >{{user.date.slice(0, 6)}}{{" "}}{{user.date.slice(23, 30)}}</div>
							
								</div>
								<div id="rightBox" class="flex-shrink-1 bg-light rounded py-2 px-3 mr-3">
									<div class="font-weight-bold mb-1">{{user.sendermessage.firstName}}
                                    <button  v-on:click="deleteMessage(user.id)"  style=" height:30px; width:30px; float: right; 
                                    margin-right:5px;" type="button" class="btn btn-sm btn-danger mr-1">
                                    <i class="fas fa-close" style="font-size:15px; "></i>
                                    </button>
                                   </div>
                                    
                                {{user.content}}
                            </div>
							</div>

							<div class="chat-message-left pb-4" v-if="user.receivermessage.id!==receiverId"  >
								<div>
           <img :src="'http://46.105.36.240:3000/'+ profileimgage"
                style="width: 70px;height:70px;border-radius:55px" />
                                     
                                     <div  >{{user.date.slice(7, 22)}}</div>
                                     <div  >{{user.date.slice(0, 6)}}{{" "}}{{user.date.slice(23, 30)}}</div>
							
								</div>
                    		
								<div   class="flex-shrink-1 bg-light rounded py-2 px-3 ml-3">
									<div  class="font-weight-bold mb-1">{{user.sendermessage.firstName}}</div>
								{{user.content}}
                                
                                 </div>
							</div>
                           </tr>
						</div>
					</div>

					<div class="flex-grow-0 py-3 px-4 border-top">
						<div class="input-group">
							<input type="text" v-model="content" class="form-control" placeholder="Type your message">
							<button @click="sendMessage()" class="btn " style="background-color:orangered;text:18px">Send</button>
						</div>
					</div>

				</div>



</div>

		

  </div>
</template>

<script>
import Swal from 'sweetalert2';
export default {
name:"chatroomMyRev",

data() {
    return {
        id:'',
        loading: true,
      users: [],
      msgId:'',
       userId:localStorage.getItem('userId'),
       firstName:localStorage.getItem('receiver-firstName'),
       lastName:localStorage.getItem('receiver-lastName'),
        departuretown:localStorage.getItem('AnnRev-departuretown'),
       destinationtown:localStorage.getItem('AnnRev-destinationtown'),
       receiverId:localStorage.getItem('receiver-id'),
       profileimgage:localStorage.getItem('receiver-prifil-image'),
       content:'',
       date: "",
 

    }
  },

   async created() {

var axios1 = require('axios');
var config1 = {
  method: 'get',
  url: 'http://46.105.36.240:3000/chat/messages/'+localStorage.getItem('receiver-id'),
  headers: { 
    'Content-Type': 'application/json', 
    'Authorization': 'Bearer '+ localStorage.getItem('access-token')  },
};

axios1(config1)
 .then(res => {
            this.users = res.data;
        })
.catch(function (error) {
  console.log(error);
    Swal.fire({
  icon: 'error',
  title: 'Oops... Session Expired!',
  text: 'You need to login Again!',
})
});
  },






methods:{


    
 deleteMessage(id) {
const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    width: 7000,
    confirmButton: 'btn btn-success',
    cancelButton: 'btn btn-danger'
  },
  buttonsStyling: false
})

swalWithBootstrapButtons.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Yes, delete it!',
  cancelButtonText: 'No, cancel!',
  reverseButtons: true
}).then((result) => {
  if (result.isConfirmed) {


var axios = require('axios');
var config = {
  method: 'delete',
  url: 'http://46.105.36.240:3000/delete/message/'+id+'/messages',
  headers: { 
    'Content-Type': 'application/json', 
    'Authorization': 'Bearer '+ localStorage.getItem('access-token')}
};

axios(config)
.then(function (response) {
  console.log(JSON.stringify(response.data));
  window.location.href = "/chatRoomMyRev"
})
.catch(function (error) {
  console.log(error);
   localStorage.clear()
window.location.href = "/"
});


    swalWithBootstrapButtons.fire(

      'Deleted!',
      'Your file has been deleted.',
      'success'
    )
  } else if (
    /* Read more about handling dismissals below */
    result.dismiss === Swal.DismissReason.cancel
  ) {
    swalWithBootstrapButtons.fire(
      'Cancelled',
      'Your imaginary file is safe :)',
      'error'
    )
  }
})
      },

    sendMessage(){
        var axios = require('axios');
var data = JSON.stringify({
 
  "content": this.content,
  "status": "ENABLED",
  "reservationDto": {
    "id": localStorage.getItem('Rev-id'),
    "description": localStorage.getItem('userRev-descriptionId'),
    "documents": localStorage.getItem('Rev-documents'),
    "computer": localStorage.getItem('Rev-computer'),
    "status": "ENABLED",
    "quantitykilo":localStorage.getItem('Rev-quantitykilo'),
    "date": localStorage.getItem('Rev-date'),
    "totalprice": localStorage.getItem('Rev-totalprice'),
    "userDto": {
       "id":  localStorage.getItem('receiver-id') ,
      "firstName": localStorage.getItem('receiver-firstName') ,
      "lastName":localStorage.getItem('receiver-lastName') ,
     "profileimgage": localStorage.getItem('receiver-profil-image') ,
     "pseudo": localStorage.getItem('receiver-pseudo') ,
      "email": localStorage.getItem('receiver-email') ,
    "roleDtos": [
      {
        "id": 2,
        "name": "ROLE_CLIENT"
      }
    ],
    "status": "ENABLED"
    },
    "announcementDto": {
      "id": localStorage.getItem('AnnRev-id') ,
    "departuredate": localStorage.getItem('AnnRev-departuredate') ,
    "arrivaldate": localStorage.getItem('AnnRev-arrivaldate') ,
    "departuretown": localStorage.getItem('AnnRev-departuretown') ,
    "destinationtown": localStorage.getItem('AnnRev-destinationtown') ,
    "quantity": localStorage.getItem('AnnRev-quantity') ,
    "computer":  localStorage.getItem('AnnRev-computer') ,
    "restriction": localStorage.getItem('AnnRev-restriction') ,
    "document": localStorage.getItem('AnnRev-document') ,
    "status": "ENABLED",
    "cni": "string",
    "ticket": "string",
    "covidtest": "string",
    "price": localStorage.getItem('AnnRev-price') ,
    "validation": true,
    "userDto": {
   "id": localStorage.getItem('userId'),
    "firstName": localStorage.getItem('firstName'),
    "lastName": localStorage.getItem('lastName'),
     "profileimgage": null,
    "pseudo": localStorage.getItem('pseudo'),
    "email": localStorage.getItem('email'),
      "roleDtos": [
        {
          "id": 2,
          "name": "ROLE_CLIENT"
        }
      ],
      "status": "ENABLED"
      }
    }
  },
  "sendermessage": {
    "id": localStorage.getItem('userId'),
    "firstName": localStorage.getItem('firstName'),
    "lastName": localStorage.getItem('lastName'),
     "profileimgage": null,
    "pseudo": localStorage.getItem('pseudo'),
    "email": localStorage.getItem('email'),
    "roleDtos": [
      {
        "id": 2,
        "name": "ROLE_CLIENT"
      }
    ],
    "status": "ENABLED"
  },
  "receivermessage": {

    "id":  localStorage.getItem('receiver-id') ,
      "firstName": localStorage.getItem('receiver-firstName') ,
      "lastName":localStorage.getItem('receiver-lastName') ,
     "profileimgage": localStorage.getItem('receiver-profil-image') ,
     "pseudo": localStorage.getItem('receiver-pseudo') ,
      "email": localStorage.getItem('receiver-email') ,
      "roleDtos": [
        {
          "id": 2,
          "name": "ROLE_CLIENT"
        }
      ],
      "status": "ENABLED"
  },
});

var config = {
  method: 'post',
  url: 'http://46.105.36.240:3000/add/message',
  headers: { 
    'Content-Type': 'application/json', 
    'Authorization': 'Bearer '+ localStorage.getItem('access-token')  },

  data : data
};

axios(config)
.then(function (response) {
  console.log(JSON.stringify(response.data));
   window.location.reload()
})
.catch(function (error) {
  console.log(error);
   Swal.fire({
  icon: 'error',
  title: 'Oops...',
  text: 'Your Session has Expire! Login Again',
})
});

    }
}
}
</script>
<style lang="scss" scoped>

.chat-messages {
     display: flex;
    flex-direction: column;
    height:74vh;
    background-color: #d5f2ff;
    overflow-y: scroll;
  top:0px;
  right:0px;
  bottom:0px;
  left:0px;
}

.chat-message-left,
.chat-message-right {
    display: flex;
    flex-shrink: 0;
    color: #000000;
    
    
}

.chat-message-left {
     color: #000000;
}

.chat-message-right {
    flex-direction: row-reverse;
    color: #000000;
    
}
.py-3 {
    padding-top: 1rem!important;
    padding-bottom: 1rem!important;
}
.px-4 {
    padding-right: 1.5rem!important;
    padding-left: 1.5rem!important;
}
.flex-grow-0 {
    flex-grow: 0!important;
}
.rightBox{
    background:greenyellow;
}
.border-top {
    border-top: 1px solid #ff7b00!important;
}
</style>