<template>
<div>
    <lognav/>
    <sliderVue />
    <announcehomeVue />
 <FunctioningDGAVue/>
  <footerVue />
</div>


</template>

<script>
import lognav from '../components/lognav.vue'
import footerVue from "@/components/footer.vue"
import sliderVue from '../components/slider.vue'
import FunctioningDGAVue from '../components/FunctioningDGA.vue'
import announcehomeVue from '../components/announcehome.vue'
export default {
 name: "Home",
  components: {
    sliderVue,
    announcehomeVue,
    FunctioningDGAVue,
    lognav,
    footerVue
  },
}
</script>

<style lang="scss">

body {
	background-color: var(--white);
	background: url("https://canso.fra1.digitaloceanspaces.com/uploads/2021/10/Orthagon-1024x576.jpg");
	background-attachment: fixed;
	background-position: center;
	background-repeat: no-repeat;
	background-size: cover;
	display: grid;
	height: 100vh;
    background{
opacity: 3.7;
    }
    
}
</style>