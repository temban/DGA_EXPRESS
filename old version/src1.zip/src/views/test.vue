<template>
  <div id="app">
    <div v-if="this.alert.display" class="alert">
      {{ alert.message }}
    </div>
    <div class="input">
      <br />
      <input v-model="userInput" type="text" placeholder="Dynamic Search..." />
    </div>
    <div class="explanation">
      <i>
        <b>Explanation:</b>
        You can search with the username
        <small>(Bret, Antonette, etc.)</small>
        at the top of the cards.
      </i>
    </div>
    <div class="container">
      <div class="card" v-for="user in searchResult" :key="user.id">
        <div class="header">
          <span class="subHeaderText">{{ user.destinationtown }}</span>
          <span class="headerText">{{ user.departuredate }}</span>
        </div>
        <div class="footer">
          <span class="descriptionText">{{ user.destinationtown }}</span>
          <span class="descriptionText">{{ user.arrivaldate }}</span>
          <span class="descriptionText">{{ user.price }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userInput: "",
      searchResult: [],
      users: [],
      alert: {
        display: false,
        message: ""
      }
    };
  },
  created() {

    fetch("http://46.105.36.240:3000/announcements")
    .then(response => response.json())
    .then(data => {
  this.users = data.reverse();
        this.searchResult = this.users;
          this.loading = false
     // this.idAnn= data[2].userDto.id
      //console.log( data[2].userDto.id);
    })
    .catch(err => {
      console.error(err);
    });
  },
  watch: {
    userInput(word) {
      if (word.length > 0) {
        this.searchResult = this.users.filter((element) =>
          element.destinationtown.includes(word)
        );
        if (this.searchResult.length === 0) {
          this.alert.message = "This username not found.";
          this.alert.display = true;
          console.log("Not Found!");
        } else {
          this.alert.message = "";
          this.alert.display = false;
        }
      } else {
        this.searchResult = this.users;
      }
    }
  },
  methods: {
    doSomething() {
      alert("Hello!");
    }
  }
};
</script>

<style lang="scss">
// variables
$headerTextColor: #404040;
$headerTextSize: 1.6em;
$headerTextWeight: 700;

$subHeaderTextColor: #808080;
$subHeaderTextSize: 1em;
$subHeaderTextWeight: 400;

$descriptionTextColor: #404040;
$descriptionTextSize: 1em;
$descriptionTextWeight: 400;

$lightBackground: #fbf8fb;
$darkBackground: #7882a4;
$textHoverColor: #f2f2f2;

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03em;
}

.container {
  display: flex;
  margin: 4px;
  justify-content: center;
  flex-wrap: wrap;
}

.alert {
  position: absolute;
  bottom: 36px;
  right: 36px;
  padding: 10px 14px 10px 14px;
  background-color: #f2f2f2;
  border-radius: 14px;
  color: $subHeaderTextColor;
  font-size: $subHeaderTextSize;
  font-weight: $subHeaderTextWeight;
}

.input {
  display: flex;
  justify-content: center;
  margin-top: 1em;

  input {
    min-width: 280px;
    padding: 12px;
    border-width: 2px;
    background-color: $lightBackground;
    color: $subHeaderTextColor;
    border-radius: 14px;
    border: none;

    &:focus {
      outline: none;
    }
  }
}

.explanation {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 2em 3em 1em 3em;
  color: $descriptionTextColor;
  font-size: $descriptionTextSize;
  font-weight: $descriptionTextWeight;
}

.card {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 1.5em;
  margin: 18px;
  padding: 12px;
  background-color: $lightBackground;
  border-radius: 32px;
  min-width: 280px;
  min-height: 220px;
  transition: 125ms;

  .header {
    display: flex;
    flex-direction: column;
    gap: 0.4em;
  }
  .footer {
    display: flex;
    flex-direction: column;
    gap: 0.4em;
  }

  .headerText {
    color: $headerTextColor;
    font-size: $headerTextSize;
    font-weight: $headerTextWeight;
    border-bottom: 1px solid #bb6464;
  }

  .subHeaderText {
    color: $subHeaderTextColor;
    font-size: $subHeaderTextSize;
    font-weight: $subHeaderTextWeight;
  }

  .descriptionText {
    color: $descriptionTextColor;
    font-size: $descriptionTextSize;
    font-weight: $descriptionTextWeight;
  }

  &:hover {
    transform: translate(0) scale(1.1);
    background-color: $darkBackground;
    cursor: pointer;
    transition: 125ms;
    .headerText {
      color: $textHoverColor;
    }
    .subHeaderText {
      color: $textHoverColor;
    }
    .descriptionText {
      color: $textHoverColor;
    }
  }
  &:active {
    transform: translate(0) scale(1);
  }
}
</style>
