<template>
    <div style="">
        <div style="margin-left:60px;">
            <lognavVue />
        </div>
        <usersidebarVue />

        <div>
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">My Articles</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="">
                                <div>
                                    <div class="container bootstrap snippets bootdey" style="background:#d9dedf; ">
                                        <section id="contact" class="gray-bg padding-top-bottom">
                                            <div class="container bootstrap snippets bootdey">
                                                <div class="row">
                                                    <form id="Highlighted-form" class="col-sm-6 col-sm-offset-3"
                                                        action="contact.php" method="post" novalidate="">

                                                        <div class="form-group">

                                                            <div class="controls">
                                                                <h6>Name</h6><input v-model="article.name"
                                                                    id="contact-name" name="contactName"
                                                                    class="form-control requiredField Highlighted-label"
                                                                    type="text" readonly>
                                                                <i class="fa fa-calendar"
                                                                    style="margin-bottom:-30px"></i>
                                                            </div>
                                                        </div><!-- End name input -->
                                                        <div class="form-group">

                                                            <div class="controls">
                                                                <h6>Cathegory</h6> <input
                                                                    v-model="article.cathegory.name" id="contact-name"
                                                                    name="contactName"
                                                                    class="form-control requiredField Highlighted-label"
                                                                    data-new-placeholder="Your name" type="text"
                                                                    readonly>
                                                                <i class="fa fa-calendar"></i>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">

                                                            <div class="controls">
                                                                <h6>Location</h6> <input v-model="article.location"
                                                                    id="contact-name" name="contactName"
                                                                    class="form-control requiredField Highlighted-label"
                                                                    type="text" readonly>
                                                                <i class="fa fa-plane"></i>
                                                            </div>
                                                        </div>
                                                        <!-- End name input -->
                                                        <div class="form-group">

                                                            <div class=" controls">
                                                                <h6> Quantity</h6><input v-model="article.quantity"
                                                                    id="contact-mail" name="email"
                                                                    class="form-control requiredField Highlighted-label"
                                                                    type="text" readonly>
                                                                <i class="fa fa-id-card"></i>
                                                            </div>
                                                        </div>
                                                        <!-- End name input -->
                                                        <div class="form-group">

                                                            <div class=" controls">
                                                                <h6>Price</h6> <input v-model="article.price"
                                                                    id="contact-mail" name="email"
                                                                    class="form-control requiredField Highlighted-label"
                                                                    type="email" readonly>
                                                                <i class="fa fa-hospital-o"></i>
                                                            </div>
                                                        </div>
                                                        <!-- End email input -->
                                                        <div class="form-group">

                                                            <div class="controls">
                                                                <h6>Description</h6> <textarea
                                                                    v-model="article.description" id="contact-message"
                                                                    name="comments" placeholder="Your message"
                                                                    class="form-control requiredField Highlighted-label"
                                                                    rows="6" readonly></textarea>
                                                                <i class="fa fa-comment"></i>
                                                            </div>
                                                        </div><!-- End textarea -->
                                                    </form><!-- End Highlighted-form -->
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">

            <b-container style="margin-left:32px; margin-bottom: 30px;background-color:white;">
                <h3 class="mt-2 mb-3 float-left text-primary">My Articles</h3>
                <button @click="createArt()" style=" display:flex;
                      align-items:center;
                      justify-content:left;" class="create">
                    <i class="fa fa-plus" style="font-size:20px;color:white; margin-top:20px;margin-left:-22px"></i>
                    <span style="font-size:20px; margin-left:-10px">New Article</span></button>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">category</th>
                            <th scope="col">quantity</th>
                            <th scope="col">price</th>
                            <th scope="col">location</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody style="text-transform: capitalize">
                        <tr v-for="item in articles" v-bind:key="item.id">
                            <td>{{ item.name }}</td>
                            <td>{{ item.cathegory.name }}</td>
                            <td>{{ item.quantity }}</td>
                            <td>{{ item.price }}</td>
                            <td>{{ item.location }}</td>
                            <td>
                                <form>
                                    <!-- <button  v-on:click="view(user.id)" data-target="#exampleModal" data-toggle="modal" style="height:45px; width:40px;  margin-right:5px;" type="button" class="btn btn-sm btn-info mr-1" disabled><i class="fa fa-eye" style="font-size:20px"></i></button>-->

                                    <button @click="view(item.id)" data-target="#exampleModal" data-toggle="modal"
                                        style="height:45px; width:40px;  margin-right:5px;" type="button"
                                        class="btn btn-sm btn-info mr-1">
                                        <i class="fa fa-eye" style="font-size:20px"></i>
                                    </button>
                                    <router-link style="height:45px; width:40px;" class="btn btn-sm btn-info mr-1"
                                        :to="{ name: 'EditArticle', params: { id: item.id } }"><i class="fa fa-pencil"
                                            style="font-size:20px"></i></router-link>
                                    <button @click="deleteArticle(item.id)" style="height:45px; width:40px;"
                                        type="button" class="btn btn-sm btn-danger"><i class="fa fa-trash"
                                            style="font-size:20px"></i></button>

                                </form>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </b-container>
            <!-- Fim tabela -->
        </div>
        <footerVue />
    </div>
</template>

<script>
import Swal from 'sweetalert2';
import footerVue from "@/components/footer.vue"
import lognavVue from "../components/lognav.vue";
import usersidebarVue from "../components/usersidebar.vue";
export default {
    name: 'MyAnnoucements',
    data() {
        return {
            loading: true,
            users: [],
            users1: [],
            id: '',
            articles: [],
            article: {
                name: "",
                description: "",
                price: 0,
                quantity: 0,
                status: "",
                date: "",
                location: "",
                cathegory: {
                    name: ''
                }
            }
        }
    },
    components: {
        lognavVue,
        usersidebarVue,
        footerVue
    },
    // Ao criar o componente, é feito uma requisição GET para a API do backend
    async created() {
        
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", "Bearer " + localStorage.getItem('access-token'));

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch("http://46.105.36.240:3000/user/"+JSON.parse(localStorage.getItem('infoUser')).id+"/articles/", requestOptions)
            .then(response => response.text())
            .then(result => {
                this.articles = JSON.parse(result);
                console.log(result);
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                })
                console.log('error', error)
            });

    },
    methods: {
        deleteArticle(id) {
            console.log(id);
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    width: 7000,
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {

                    var myHeaders = new Headers();
                    myHeaders.append("Content-Type", "application/json");
                    myHeaders.append("Authorization", "Bearer " + localStorage.getItem("access-token"));

                    var requestOptions = {
                        method: 'DELETE',
                        headers: myHeaders,
                        redirect: 'follow'
                    };

                    fetch("http://46.105.36.240:3000/delete/article/" + id, requestOptions)
                        .then(response => response.text())
                        .then(result => {
                            console.log(result)
                            swalWithBootstrapButtons.fire(

                                'Deleted!',
                                'Your file has been deleted.',
                                'success'
                            )
                            window.location.reload()
                        })
                        .catch(error => console.log('error', error));

                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your imaginary file is safe :)',
                        'error'
                    )
                }
            })
        },
        lockedAnn() {
            Swal.fire({
                icon: 'error',
                title: 'Oops... Traveled Has Been Reserverd!',
                text: 'Contact DGA Client Service for more Info!',
            })
        },

        createArt() {
            window.location.href = "/createarticle"
        },

        view(id) {
            
            var myHeaders = new Headers();
            myHeaders.append("Content-Type", "application/json");
            myHeaders.append("Authorization", "Bearer "+localStorage.getItem("access-token"));

            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };

            fetch("http://46.105.36.240:3000/articles/"+id, requestOptions)
                .then(response => response.text())
                .then(result => this.article = JSON.parse(result))
                .catch(error => console.log('error', error));
        },

        noUpdate() {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Something went wrong!',
                footer: '<a href="">Why do I have this issue?</a>'
            })
        },

        deleteUser(id) {
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    width: 7000,
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {

                    var myHeaders = new Headers();
                    myHeaders.append("Content-Type", "application/json");
                    myHeaders.append("Authorization", "Bearer " + localStorage.getItem("access-token"));

                    var requestOptions = {
                        method: 'DELETE',
                        headers: myHeaders,
                        redirect: 'follow'
                    };

                    fetch("http://46.105.36.240:3000/delete/article/" + id, requestOptions)
                        .then(response => response.text())
                        .then(result => {
                            console.log(result)
                            swalWithBootstrapButtons.fire(

                                'Deleted!',
                                'Your file has been deleted.',
                                'success'
                            )
                            window.location.reload()
                        })
                        .catch(error => console.log('error', error));
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your imaginary file is safe :)',
                        'error'
                    )
                }
            })
        },


    }
}
</script>

<style lang="scss" scoped>
.create {

    display: inline-block;
    outline: 0;
    border: 0;
    cursor: pointer;
    will-change: box-shadow, transform;
    background: radial-gradient(100% 100% at 100% 0%, #f0b07c 0%, #ff9100 100%);
    box-shadow: 0px 2px 4px rgb(247, 152, 43), 0px 7px 13px -3px rgba(241, 188, 12, 0.993), inset 0px -3px 0px rgba(241, 103, 61, 0.795);
    padding: 0 32px;
    border-radius: 6px;
    color: #fff;
    height: 58px;
    width: 20%;
    float: right;
    margin: 10px 0 10px 0;
    font-size: 18px;
    text-shadow: 0 1px 0 rgba(241, 173, 94, 0.932);
    transition: box-shadow 0.15s ease, transform 0.15s ease;
}

.create:hover {
    box-shadow: 0px 4px 8px rgb(255, 145, 1), 0px 7px 13px -3px rgb(45 35 66 / 30%), inset 0px -3px 0px #f37018;
    transform: translateY(-2px);
}

.create:active {
    box-shadow: inset 0px 3px 7px #ff7504;
    transform: translateY(2px);
}

.h6 {
    font-size: 18px;
    font-weight: 600;
}

.contact-item .icon {
    display: block;
    font-size: 48px;
    color: #5cc9df;
    text-shadow: -2px 2px 0 rgba(0, 0, 0, 0.1);
    -webkit-transition: all .3s ease-out;
    transition: all .3s ease-out;
}

.contact-item .icon:hover {
    color: #5cc9df;
    -webkit-transform: scale(1.3) translateY(-10px);
    transform: scale(1.3) translateY(-10px);
}


.bl_form {}

.bl_form input {
    background: rgba(255, 255, 255, 0.10);
    box-shadow: 0 4px 0px rgba(0, 0, 0, 0.2);
    border: none;
    color: white;
    border-radius: 5px;
    font-size: 16px;
    outline: none;
}

.lb_wrap .lb_label.top,
.lb_wrap .lb_label.bottom {
    left: 66px !important;
}

.lb_wrap .lb_label.left {
    left: 0;
}

.lb_label {
    font-size: 18px;
    font-weight: 400;
    color: rgb(0, 0, 0);
}

.no-placeholder .lb_label {
    display: none;
}

.lb_label.active {
    color: #aaa;
}

#Highlighted-form .form-group label {
    display: none;
    font-size: 18px;
    font-weight: 100;
    text-transform: uppercase;
}

#Highlighted-form.no-placeholder .form-group label {
    display: block;
}

#Highlighted-form .controls {
    padding: 0;
    margin-top: 10px;
}

#Highlighted-form.no-placeholder .controls {
    margin-top: 0;
}

#Highlighted-form .form-control {
    display: inline;
    width: 400px;
    background: #fff;
    border: none;
    border-radius: 5px;
    outline: none;
    box-shadow: 0 4px 0 rgba(0, 0, 0, 0.05);
    height: 48px;
    font-size: 18px;
    color: rgb(0, 0, 0);
    font-weight: 400;
    padding-left: 54px;
}

#Highlighted-form .form-group.half-width {
    width: 40%;
    float: left;
}

#Highlighted-form .form-group {
    position: relative;
}

#Highlighted-form .form-group [class*=fa] {
    display: block;
    width: 45px;
    position: absolute;
    top: 0;
    left: 5px;
    margin-top: 35px;
    color: rgb(255, 115, 0);
    font-size: 24px;
    line-height: 52px;
    text-align: center;
    font-weight: 300;
    -webkit-transition: color .3s ease-out;
    transition: color .3s ease-out;
}

#Highlighted-form .form-group [class*=fa].active {
    color: #ccc;
}

#Highlighted-form.no-placeholder .form-group [class*=fa] {
    top: 10px;
}

#Highlighted-form textarea.form-control {
    height: 100px;
    width: 400px;
    min-width: 100%;
    font-size: 18px;
    font-weight: 400;
    line-height: 24px;
    padding-top: 14px;
    vertical-align: top;
}

#Highlighted-form .form-control:focus {
    outline: none;
    box-shadow: 0 4px 0 rgba(0, 0, 0, 0.05);
}

#Highlighted-form .error-message {
    padding: 5px 0;
    position: absolute;
    top: -35px;
    right: 0;
    font-size: 15px;
    line-height: 24px;
    font-weight: 400;
    color: #ff3345;
    z-index: 10;
}

#Highlighted-form.no-placeholder .error-message {
    top: 0;
}
</style>