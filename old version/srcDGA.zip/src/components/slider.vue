<template>
<div>

    <b-carousel class="b border-0"
      id="carousel-1"
      :interval="2000"
      controls
      indicators
      background="#ababab"
      img-width="1024"
      img-height="480"
      style="text-shadow: 1px 1px 2px #333;"
    >

  <b-carousel-slide>
        <template #img>
          <img
            class="d-block img-fluid w-100"
            width="1024"
            height="480"
            src="@/assets/img/44.png"
            alt="image slot"
             caption="First slide"
          >
        </template>
      </b-carousel-slide>
      <!-- Slides with img slot -->
      <!-- Note the classes .d-block and .img-fluid to prevent browser default image alignment -->
      <b-carousel-slide>
        <template #img>
          <img
            class="d-block img-fluid w-100"
            width="1024"
            height="80"
            src="@/assets/img/b.jpg"
            alt="image slot"
            style="height: 265px;"

            
          >

        </template>
      </b-carousel-slide>

      <!-- Slide with blank fluid image to maintain slide aspect ratio -->
            <b-carousel-slide>
        <template #img>
          <img
            class="d-block img-fluid w-100"
            style="height: 265px;"
            width="1024"
            height="480"
            src="@/assets/img/c.jpg"
            alt="image slot"
          >
        </template>
      </b-carousel-slide>
    </b-carousel>
<div class="wrap1s">
    <a class="button1" href="/Announcements"> <button1 ><i class="fa fa-shopping-cart"></i> Visit Our MarketPlace </button1></a>
 
</div>
    

</div>
</template>

<script>

</script>
<style>
.text {
text-align: center;
}
.b{
margin-top: -48px;

}
.b img {
  opacity: 0.8;
}

img:hover {
  opacity: 1.0;
}
</style>