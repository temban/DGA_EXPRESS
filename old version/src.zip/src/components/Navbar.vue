<template>
  <div style="margin-top:-5px;margin-bottom:49px">
  <b-navbar toggleable="lg" type="light" variant="white">

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>
        <b-navbar-brand href="/">Home</b-navbar-brand>
      <b-navbar-nav >
         <b-nav-item href="/Announcements">Travels</b-nav-item>
        <b-nav-item href="/MarketPlace">Marketplace</b-nav-item>
         <b-nav-item href="/About">About</b-nav-item>
        <b-nav-item href="#" >Contact</b-nav-item>
      </b-navbar-nav>
    

    </b-collapse>
 <div v-if="isLogged === false" style="margin-right:20px">
<a href="/Register"><button type="button" class="btn btn-outline-primary">Login</button></a>
</div>
<div v-if="isLogged === false">
<a href="/Register"><button type="button" class="btn btn-outline-primary">Register</button></a>

</div>
  </b-navbar>
 
  </div>
</template>

<script>
export default {
    name:"NavbarVue",
   data() {
    return {
        
      isLogged: this.checkIfIsLogged(),
    };
  },

         components: {
  },
       created () {
    this.$bus.$on('logged', () => {
      this.isLogged = this.checkIfIsLogged()
    })
  },
  methods: {

 singout () {
      localStorage.removeItem('access-token')
      this.isLogged = this.checkIfIsLogged()
      this.$router.push('/')
    },
    checkIfIsLogged () {
      let token = localStorage.getItem('access-token')
      //localStorage.getItem('access-token')
      if (token) {
        return true
      } else {
        return false
      }
    },


  
  },


}
</script>

<style>

* {
  font-family: 'Source Sans Pro', sans-serif;
}
.nav-link {
   color: #000!important;
   display: block;
   font-size: large;
text-align: center;
text-decoration: none;
}
</style>