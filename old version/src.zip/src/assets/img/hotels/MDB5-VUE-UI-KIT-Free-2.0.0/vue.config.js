module.exports = {
  publicPath: "./"
};
