
<template>
  <body>
    <!--<div class="mt-1 mb-1">
        
                          <img
                            src="@/assets/img/hotels/59710428.png"
                            class="rounded-circle img-fluid"
                            style="
                           
                              height: 190px;
                              width: 190px;
                            "
                          />
                        </div>-->
                      
               <div class="header__logo">
                 <a href="/" class="sign__logo2-img">  </a>  
          </div>

    <div class="main" style="margin-top: 30px">
    <a  href="/" style="   height: 55px; z-index: 100;position:absolute;;
                          width: 55px;">
                     <img
                        style="
                        position:absolute;
                          border-radius: 70px;
                          height: 35px;
                          width: 35px;
                          margin-top: 30px;
                          left: 10px; 
                        " 
                        src="@/assets/img/hotels/back.png"
                      />
    </a>            
      <input type="checkbox" id="chk" aria-hidden="true" />

      <div class="signup">
        <form  @submit="signup">
          <label for="chk" aria-hidden="true" style="margin-top: 10px"
            >Sign up</label
          >
          <div class="row" style="margin-top: -50px">
            <div class="column_left">
              <input
               v-model="firstName"
                type="text"
                name="txt"
                placeholder="First Name"
                required=""
              />
              <input  v-model="pseudo" type="text" name="pswd" placeholder="Pseudo" required="" />
              <input
              
                type="text"
                name="pswd"
                  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
              title="at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
                placeholder="Password"
                required=""
              />
              
            </div>

            <div class="column_right">
              <input
               v-model="lastName"
                type="text"
                name="txt"
                placeholder="Last Name"
                required=""
              />
              <input
               v-model="useremail"
                type="email"
                name="email"
                placeholder="E-mail"
                required=""
              />
              <input
               v-model="password"
                type="password"
                name="pswd" 
                  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
              title="at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
                placeholder="Confirm Password"
                required=""
              />
            </div>
          </div> 
  
<span style="width:35%; height:30px;margin-top: -10px; margin-left:200px;  display:flex; align-items:center; justify-content: center;">
 <input
   style="width:15px; height:15px; background: red; " 
                type="checkbox" required/> 
                
                <span >
                    I Agree <a href="/Conditions">
                <u style="color: blue">Terms of Service</u></a
              >. </span>
</span>
             
          <button type="submit" class="button">Sign up 
             <div class="spinner-border text-light spinner-border-sm" role="status" v-if="login">
          <span class="sr-only">Loading...</span></div>
          </button>
          <div class="login-choice"><span>or SigUp with</span></div>
          <SocialLogin />
        </form>
      </div>

      <div class="login">
        <form @submit="onLogin">
          <label for="chk" aria-hidden="true" >Login</label>
          <input v-model="useremail" type="email" name="email" placeholder="Email" required=" Please Insert Your E-mail!" />
          <input
          v-model="password"
            type="password"
            name="pswd"
            placeholder="Password"
            required=""
          />
        
          <button class="button1" type="submit" style="margin-top:40px">Login   
          <div class="spinner-border text-light spinner-border-sm" role="status" v-if="login">
          <span class="sr-only">Loading...</span></div>
          </button>
          <div class="login-choice" style="margin-top:30px"><span>or SignIn with</span></div>
          <SocialLogin />
        </form>
      </div>
    </div>
  </body>
</template>

<script>
import SocialLogin from "@/components/SocialLogin";
import Swal from "sweetalert2";
export default {
  name: "loginmodelVue",
  data() {
    return {
        login:false,
      loading: false,
      modalShow: false,
      useremail: "",
      password: "",
       firstName: "test",
      lastName: "test",
      pseudo: "test",
      tel: "",
    };
  },
  components: {
    SocialLogin,
  },
   mounted(){
var input = document.getElementById("phone");
var iti = window.intlTelInput(input, {
  // separateDialCode:true,
  utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.3/build/js/utils.js",
});

// store the instance variable so we can access it in the console e.g. window.iti.getNumber()
window.iti = iti;
    },
  methods: {
signup(event) {
      this.loading = true;

      let onLogin =()=>{
       event.preventDefault();
      var axios = require("axios");

      var qs = require("qs");
      var data = qs.stringify({
        useremail: this.useremail,
        password: this.password,
      });
      var config = {
        method: "post",
        url: "http://46.105.36.240:3000/login",
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Credentials": true,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        data: data,
      };

      axios(config)
        .then(function (response) {
          const temp = response.data;
          const refreshtoken = Object.values(temp)[0];
          const accesstoken = Object.values(temp)[1];
          localStorage.setItem("refresh-token", refreshtoken);
          localStorage.setItem("access-token", accesstoken);

          var config0 = {
            method: "get",
            url: "http://46.105.36.240:3000/profile",
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + localStorage.getItem("access-token"),
            },
          };

          axios(config0)
            .then((res) => {
              let a = res.data;
              if (a.pseudo == "DGA-EMPLOYEE" || a.pseudo == "Admin") {
                window.location.href = "/employeeDashboard";
              } else {
                console.log(a);
                window.location.href = "/userDashboard";
                //window.location.reload()
              }
            })
            .catch(function (error) {
              console.log(error);
            });
          this.$bus.$emit("logged", "User logged");
        })
        .catch(function (error) {
          if (error.response.status === 500) {
            Swal.fire(
              "Login Failed!",
              "Please Check Your Credentials!.",
              "error"
            );
          }
          if (error.response.status === 401) {
            Swal.fire("Login Failed!", "User Does Not Exist!.", "error");
          }
          if (error.response.status === 404) {
            Swal.fire("Failed!", "Something Went Wrong!.", "error");
          }
          console.log(error);
        }); 
      }

      var axios = require("axios");
      var data = JSON.stringify({
        "firstName": this.firstName,
        "lastName": this.lastName,
        "pseudo": this.pseudo,
        "phone": this.tel,
        "profileimgage": "",
        "email": this.useremail,
        "password": this.password,
      });

      var config = {
        method: "post",
        url: "http://46.105.36.240:3000/signup",
        headers: {
          "Content-Type": "application/json",
        },
        data: data,
      };

      axios(config)
        .then(function (response) {
               if (response.status === 200) {
            Swal.fire("Registration success", "welcome", "success");
            onLogin();
          }
            this.loading = false;
           this.load = true;
          console.log(JSON.stringify(response));
          
            
          //window.location.href = "/";
        })
        .catch(function (error) {
          console.log(error);
          if (error.response.status === 500) {
            Swal.fire("Registration Failed!", "User Already Exist!.", "error");
          }
          if (error.response.status === 404) {
            Swal.fire("Failed!", "Something Went Wrong!.", "error");
          }
        });
    },





    onLogin(event) {
      this.login = true;
      event.preventDefault();
      var axios = require("axios");

      var qs = require("qs");
      var data = qs.stringify({
        useremail: this.useremail,
        password: this.password,
      });
      var config = {
        method: "post",
        url: "http://46.105.36.240:3000/login",
        data: data,
      };

      axios(config)
        .then(function (response) {
          const temp = response.data;
          const refreshtoken = Object.values(temp)[0];
          const accesstoken = Object.values(temp)[1];
          localStorage.setItem("refresh-token", refreshtoken);
          localStorage.setItem("access-token", accesstoken);

          var config0 = {
            method: "get",
            url: "http://46.105.36.240:3000/profile",
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + localStorage.getItem("access-token"),
            },
          };

          axios(config0)
            .then((res) => {
              let a = res.data;
              if (a.pseudo == "DGA-EMPLOYEE" || a.pseudo == "Admin") {
                window.location.href = "/employeeDashboard";
              } else {
                console.log(a);
                window.location.href = "/userDashboard";
                //window.location.reload()
              }
            })
            .catch(function (error) {
              console.log(error);
            });
          this.$bus.$emit("logged", "User logged");
        })
        .catch(function (error) {
          if (error.response.status === 500) {
            Swal.fire(
              "Login Failed!",
              "Please Check Your Credentials!.",
              "error"
            );
          }
          if (error.response.status === 401) {
            Swal.fire("Login Failed!", "User Does Not Exist!.", "error");
          }
          if (error.response.status === 404) {
            Swal.fire("Failed!", "Something Went Wrong!.", "error");
          }
          console.log(error);
        });
    },
  },
};
</script>


<style>
.columns {
  width: 50%;
}
body {
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  min-height: 100vh;
  font-family:  "Times New Roman", Times, serif;
  background: linear-gradient(to bottom, #388bff, #388bff, #fff, #fff);
}
.main {
  width: 600px;
  height: 560px;
  position: relative;
  background: rgb(0, 187, 255);
  overflow: hidden;
  background: url("https://doc-08-2c-docs.googleusercontent.com/docs/securesc/68c90smiglihng9534mvqmq1946dmis5/fo0picsp1nhiucmc0l25s29respgpr4j/1631524275000/03522360960922298374/03522360960922298374/1Sx0jhdpEpnNIydS4rnN4kHSJtU1EyWka?e=view&authuser=0&nonce=gcrocepgbb17m&user=03522360960922298374&hash=tfhgbs86ka6divo3llbvp93mg4csvb38")
    no-repeat center/ cover;
  border-radius: 10px;
  box-shadow: 5px 20px 50px rgba(35, 19, 7, 0.444);
}
#chk {
  display: none;
}

.signup {
  position: relative;
  width: 100%;
  height: 100%;
}
label {
  color: #fff;
  font-size: 2.3em;
  justify-content: center;
  display: flex;
  margin: 60px;
  font-weight: bold;
  cursor: pointer;
  transition: 0.5s ease-in-out;
}
input {
  font-size: 20px;
  width: 90%;
  height: 40px;
  background: #fff;
  justify-content: center;
  display: flex;
  margin: 20px auto;
  padding: 10px;
  border: 2px solid black;
  outline: 19px;
  border-radius: 5px;
}
.button1 {
  width: 60%;
  height: 40px;
  padding: 10px;
  margin: 10px auto;
  justify-content: center;
  display: block;
  color: #fff;
  background: #00a6ff;
  font-size: 1em;
  font-weight: bold;
  margin-top: 20px;
  outline: none;
  border: none;
  border-radius: 5px;
  transition: 0.2s ease-in;
  cursor: pointer;
}
.button1:hover {
  background: #0091ff;
}
.button {
  width: 60%;
  height: 40px;
  margin: 10px auto;
  justify-content: center;
  display: block;
  color: #fff;
  background: #ff922b;
  font-size: 1em;
  font-weight: bold;
  margin-top: 20px;
  outline: none;
  border: none;
  border-radius: 5px;
  transition: 0.2s ease-in;
  cursor: pointer;
}
.button:hover {
  background: #ff7300;
}
.login {
  height: 760px;
  background: linear-gradient(to bottom, #f8961e, rgb(246, 205, 167));

  /*background: rgb(255, 154, 60);*/
  border-radius: 60% / 10%;
  transform: translateY(-150px);
  transition: 0.8s ease-in-out;
}
.login label {
  color: #0274ff;
  transform: scale(0.6);
}

#chk:checked ~ .login {
  transform: translateY(-580px);
}
#chk:checked ~ .login label {
  transform: scale(1);
}
#chk:checked ~ .signup label {
  transform: scale(0.6);
}
.column_left {
  float: left;
  width: 50%;
  padding-left: 20px;
}
.column_right {
  float: left;
  width: 50%;
  padding-right: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

</style>













<!--<template>
  <div id="app">
    <div v-if="this.alert.display" class="alert">
      {{ alert.message }}
    </div>
    <div class="input">
      <br />
      <input v-model="userInput" type="text" placeholder="Dynamic Search..." />
    </div>
    <div class="explanation">
      <i>
        <b>Explanation:</b>
        You can search with the username
        <small>(Bret, Antonette, etc.)</small>
        at the top of the cards.
      </i>
    </div>
    <div class="container">
      <div class="card" v-for="user in searchResult" :key="user.id">
        <div class="header">
          <span class="subHeaderText">{{ user.destinationtown }}</span>
          <span class="headerText">{{ user.departuredate }}</span>
        </div>
        <div class="footer">
          <span class="descriptionText">{{ user.destinationtown }}</span>
          <span class="descriptionText">{{ user.arrivaldate }}</span>
          <span class="descriptionText">{{ user.price }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userInput: "",
      searchResult: [],
      users: [],
      alert: {
        display: false,
        message: ""
      }
    };
  },
  created() {

    fetch("http://46.105.36.240:3000/announcements")
    .then(response => response.json())
    .then(data => {
  this.users = data.reverse();
        this.searchResult = this.users;
          this.loading = false
     // this.idAnn= data[2].userDto.id
      //console.log( data[2].userDto.id);
    })
    .catch(err => {
      console.error(err);
    });
  },
  watch: {
    userInput(word) {
      if (word.length > 0) {
        this.searchResult = this.users.filter((element) =>
          element.destinationtown.includes(word)
        );
        if (this.searchResult.length === 0) {
          this.alert.message = "This username not found.";
          this.alert.display = true;
          console.log("Not Found!");
        } else {
          this.alert.message = "";
          this.alert.display = false;
        }
      } else {
        this.searchResult = this.users;
      }
    }
  },
  methods: {
    doSomething() {
      alert("Hello!");
    }
  }
};
</script>

<style lang="scss">
// variables
$headerTextColor: #404040;
$headerTextSize: 1.6em;
$headerTextWeight: 700;

$subHeaderTextColor: #808080;
$subHeaderTextSize: 1em;
$subHeaderTextWeight: 400;

$descriptionTextColor: #404040;
$descriptionTextSize: 1em;
$descriptionTextWeight: 400;

$lightBackground: #fbf8fb;
$darkBackground: #7882a4;
$textHoverColor: #f2f2f2;

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03em;
}

.container {
  display: flex;
  margin: 4px;
  justify-content: center;
  flex-wrap: wrap;
}

.alert {
  position: absolute;
  bottom: 36px;
  right: 36px;
  padding: 10px 14px 10px 14px;
  background-color: #f2f2f2;
  border-radius: 14px;
  color: $subHeaderTextColor;
  font-size: $subHeaderTextSize;
  font-weight: $subHeaderTextWeight;
}

.input {
  display: flex;
  justify-content: center;
  margin-top: 1em;

  input {
    min-width: 280px;
    padding: 12px;
    border-width: 2px;
    background-color: $lightBackground;
    color: $subHeaderTextColor;
    border-radius: 14px;
    border: none;

    &:focus {
      outline: none;
    }
  }
}

.explanation {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 2em 3em 1em 3em;
  color: $descriptionTextColor;
  font-size: $descriptionTextSize;
  font-weight: $descriptionTextWeight;
}

.card {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 1.5em;
  margin: 18px;
  padding: 12px;
  background-color: $lightBackground;
  border-radius: 32px;
  min-width: 280px;
  min-height: 220px;
  transition: 125ms;

  .header {
    display: flex;
    flex-direction: column;
    gap: 0.4em;
  }
  .footer {
    display: flex;
    flex-direction: column;
    gap: 0.4em;
  }

  .headerText {
    color: $headerTextColor;
    font-size: $headerTextSize;
    font-weight: $headerTextWeight;
    border-bottom: 1px solid #bb6464;
  }

  .subHeaderText {
    color: $subHeaderTextColor;
    font-size: $subHeaderTextSize;
    font-weight: $subHeaderTextWeight;
  }

  .descriptionText {
    color: $descriptionTextColor;
    font-size: $descriptionTextSize;
    font-weight: $descriptionTextWeight;
  }

  &:hover {
    transform: translate(0) scale(1.1);
    background-color: $darkBackground;
    cursor: pointer;
    transition: 125ms;
    .headerText {
      color: $textHoverColor;
    }
    .subHeaderText {
      color: $textHoverColor;
    }
    .descriptionText {
      color: $textHoverColor;
    }
  }
  &:active {
    transform: translate(0) scale(1);
  }
}
</style>-->
