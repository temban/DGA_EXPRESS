
<template>
  <div>
    <div>
      <lognavVue />
    </div>
  <div v-if="loading" style="background:rgba(0,0,0,0.3);height:100vh;width:100vw;position:fixed;top:0;left:0;z-index: 100;"> 
         <div class="ring">Loading</div>
    </div>

    <div class="container">
      <div class="main-body">

        <!-- /Breadcrumb -->


        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 gutters-sm">

          <div class="col mb-3" v-for="(item, idx) in articles" v-bind:key="idx">


            <div class="card ma-cart" style="border-radius: 15px; padding:-90px">
              <div class="card-body text-left">
                <img class="d-block img-fluid w-100 imgSlide"
                  :src="`http://46.105.36.240:3000/article/image?file=${item.mainImage}`" alt="image slot">

                <span class="mb-1 art-title">{{ item.name }}</span><br />
                <span class="mb-1 art-0 text-muted"><i class="fa fa-chevron-down text-warning"></i> {{
                    item.cathegory.name
                }}</span><br />
                <br />
                <span class="mb-1 art-0"><i class="fa fa-map-marker text-warning"></i> {{ item.location }}</span><br />
                <span class="mb-1 text-muted art-0"><i class="fa fa-money text-warning"></i> {{ item.price }} <b
                    style="color: rgb(63, 167, 247);">{{ subInfo.currency }}</b></span>
                <h6 style="text-transform: capitalize" class="mb-2 text-muted text-art"><i
                    class="fa fa-user text-warning"></i> {{ item.user.firstName }}</h6>


                <div style="margin-top:20px" class="mb-2 pb-2">
                  <button type="button" v-on:click="view(item)" data-target="#exampleModal" data-toggle="modal"
                    style="height:35px; float:left ;" class="btn btn-outline-primary btn-floating">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                  </button>
                  <button v-if="infoUser.id !== item.user.id" @click="tchat(item, item.user)"
                    style="height:35px; float:left ;" class="btn btn-outline-primary btn-floating ml-1">
                    <i class="fa fa-comment" aria-hidden="true"></i>
                  </button>


                  <button v-if="isLogged === true && infoUser.id !== item.user.id" @click="addToCard(item)"
                    v-b-modal.modal-multi-4 type="button" style="height:38px; float:right ;"
                    class="btn btn-warning btn-rounded btn-sm btn-floating">
                    + Add to card
                  </button>
                  <button v-if="isLogged === false" v-b-modal.modal-multi-4 type="button"
                    style="height:38px; width:50%;  float:right ;" class="btn btn-outline-warning btn-rounded btn-sm btn-floating">
                    Login to buy
                  </button>

                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    <div>
      <div>
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 v-if="sortCart == `art`" class="modal-title" id="exampleModalLabel"> Info</h5>
                <h5 v-else-if="sortCart == `basket`" class="modal-title" id="exampleModalLabel">Basket</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="">
                  <div>
                    <div class="container bootstrap snippets bootdey" style="background:#d9dedf; ">
                      <section id="contact" class="gray-bg padding-top-bottom">
                        <div v-if="sortCart == `art`" class="container bootstrap snippets bootdey">
                          <div class="row">
                            <b-carousel id="carousel-1" class="my-img" v-model="slide" controls background="#000"
                              img-width="1024" img-height="480" style="text-shadow: 1px 1px 2px #000;"
                              @sliding-start="onSlideStart" @sliding-end="onSlideEnd">
                              <b-carousel-slide v-for="(top, id) in path" class="my-img" v-bind:key="id">
                                <template #img class="img">
                                  <img class="d-block img-fluid w-100 my-img0"
                                    :src="`http://46.105.36.240:3000/article/image?file=${top}`" alt="image slot">
                                </template>
                              </b-carousel-slide>
                            </b-carousel>
                          </div>
                          <div class="row">
                            <form id="Highlighted-form" class="col-sm-6 col-sm-offset-3" novalidate="">
                              <!-- End email input -->
                              <div class="form-group">
                                <div class=" controls">
                                  <h6>Name</h6> <input v-model="article.name" id="contact-mail" name="email"
                                    class="form-control requiredField Highlighted-label" type="email" readonly>
                                  <!-- <i class="fa fa-hospital"></i> -->
                                </div>
                              </div>
                              <div class="form-group">
                                <div class=" controls">
                                  <h6>Cathegory</h6> <input v-model="article.cathegory.name" id="contact-mail"
                                    name="email" class="form-control requiredField Highlighted-label" type="email"
                                    readonly>
                                  <!-- <i class="fa fa-hospital"></i> -->
                                </div>
                              </div>
                              <div class="form-group">
                                <div class=" controls">
                                  <h6>Location</h6> <input v-model="article.location" id="contact-mail" name="email"
                                    class="form-control requiredField Highlighted-label" type="email" readonly>
                                  <!-- <i class="fa fa-hospital"></i> -->
                                </div>
                              </div>
                              <div class="form-group">
                                <div class=" controls">
                                  <h6>Quantity</h6> <input v-model="article.quantity" id="contact-mail" name="email"
                                    class="form-control requiredField Highlighted-label" type="email" readonly>
                                  <!-- <i class="fa fa-hospital"></i> -->
                                </div>
                              </div>

                              <div class="form-group">
                                <div class=" controls">
                                  <h6>Price</h6> <input v-model="article.price" id="contact-mail" name="email"
                                    class="form-control requiredField Highlighted-label" type="email" readonly>
                                  <!-- <i class="fa fa-hospital"></i> -->
                                </div>
                              </div>

                              <div class="form-group">
                                <div class="controls">
                                  <h6>Description</h6> <textarea v-model="article.description" id="contact-message"
                                    name="comments" placeholder="Your message"
                                    class="form-control requiredField Highlighted-label" rows="3" readonly></textarea>
                                  <!-- <i class="fa fa-comment"></i> -->
                                </div>
                              </div>
                              <div class="form-group">
                                <div class=" controls">
                                  <h6>Owner</h6> <input v-model="article.user.firstName" id="contact-mail" name="email"
                                    class="form-control requiredField Highlighted-label" type="email" readonly>
                                  <!-- <i class="fa fa-hospital"></i> -->
                                </div>
                              </div>

                            </form><!-- End Highlighted-form -->
                          </div>
                        </div>
                        <div v-else-if="sortCart == `basket`" class="container bootstrap snippets bootdey">
                          <table class="table table-striped table-hover table-borderless table-vcenter font-size-sm">
                            <thead>
                              <tr class="text-uppercase">
                                <th class="font-w100">Name</th>
                                <th class="font-w100">Quantity</th>
                                <th class="font-w100">dispo</th>
                                <th class="font-w100">UP</th>
                                <th class="font-w100">del</th>

                              </tr>
                            </thead>
                            <tbody style="text-transform: capitalize">
                              <tr v-for="(item, idx) in basket" v-bind:key="idx">
                                <td>{{ item.name }}</td>
                                <td><input @change="newTotal" type="number" v-model="quantities[idx]" min="1"
                                    :max="item.quantity"></td>
                                <td>{{ item.quantity }}</td>
                                <td>{{ item.price }}</td>
                                <td @click="remov(idx)" class="btn text-danger close">&times;</td>
                              </tr>
                            </tbody>
                          </table>
                          <div class="text-uppercase pb-4">
                            Total <span class="">{{ total }} <b style="color: rgb(63, 167, 247);">{{
                                subInfo.currency
                            }}</b></span>
                            <button @click="buy(), makePayment()" type="button" style="height:38px; float:right ;"
                              class="btn btn-warning btn-rounded btn-sm btn-floating"> Buy </button>
                          </div>
                        </div>
                      </section>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

  <div v-if="errors" > 
                   <pageNotFoundVue/>
                   </div> 
                   <div v-if="errors1"><pageNotFoundNoDataVue/></div>

    </div>
    <button @click="viewBasket" type="button" class="icon-button panier" data-target="#exampleModal"
      data-toggle="modal">
      <span class="material-icons">shopping_cart</span>
      <span class="icon-button__badge">{{ basket.length }}</span>
    </button>
  </div>
</template>
<script>
import pageNotFoundNoDataVue from "../components/pageNotFoundNoData.vue";
import pageNotFoundVue from "./pageNotFound.vue"
import axios from 'axios'
import Swal from 'sweetalert2'
export default {
  name: "allTravels",
  data() {
    return {
      infoUser: {},
        errors:false,
      errors1:false,
      loading: true,
      userIdAnnouncement: localStorage.getItem('userId'),
      isLogged: this.checkIfIsLogged(),
      id: '',
      users1: [],
      articles: [],
      path: [],
      modalShow: false,
      article: {
        name: "",
        description: "",
        price: 0,
        quantity: 0,
        status: "",
        date: "",
        location: "",
        cathegory: {
          name: ''
        },
        user:{firstName:''}
      },
      sortCart: "art",
      total: 0,
      basket: [],
      quantities: [],
      employee: [],
      subInfo: [],
      amount: this.total,
    }
  },
  components: {
     pageNotFoundVue,
    pageNotFoundNoDataVue,
  },

  async created() {


        var axios = require('axios');

var config = {
  method: 'get',
  url: 'http://46.105.36.240:3000/search/cathegoies/90d4b187-847b-4d6e-914f-cf5218a54940/articles/PS4',
  headers: { 
    'Content-Type': 'application/json', 
  }
};

axios(config)
.then(function (response) {
  console.log('blaise', response.data);
            this.articles = response.data;
              
        })
        .catch((err) => {
          console.error(err);
            this.errors1=true
            this.loading = false;
        });



    var requestOptions1 = { method: 'GET', redirect: 'follow' };

    fetch("http://46.105.36.240:3000/sub/informations/view", requestOptions1)
      .then(response => response.text())
      .then(result => {
        if (JSON.parse(result).length !== 0) {
          this.subInfo = JSON.parse(result)[0]
        }
      })
      .catch(error => console.log('error', error));


    let bask = JSON.parse(localStorage.getItem("basket"))
    if (bask) {
      this.basket = bask[0]
      this.quantities = bask[1]
      this.total = 0
      for (let i = 0; i < this.basket.length; i++) {
        this.total += this.basket[i].price * this.quantities[i]
      }
    }
    this.$bus.$on('logged', () => {
      this.isLogged = this.checkIfIsLogged()
    }),

    //  await fetch("http://46.105.36.240:3000/articles/available")
    //    .then(response => response.json())
    //     .then((data) => {
    //          if (data=="") {
    //            this.loading = false;
    //          this.errors=true
    //      } else {
    //         this.loading = false;
    //        this.articles = data.reverse();
              
    //      }
    //    })
    //    .catch((err) => {
    //      console.error(err);
    //        this.errors1=true
    //        this.loading = false;
    //    });




//    var requestOptions = {
//      method: 'GET',
//      redirect: 'follow'
//    };

//    fetch("http://46.105.36.240:3000/articles/available", requestOptions)
//      .then(response => response.text())
//      .then(result => {
//          if (result==[]) {
//                this.loading = true;
//              this.errors=true
//          } else {
//              this.articles = JSON.parse(result)
//               this.loading = false;
//          }
       
//console.log(' Blaise', JSON.parse(result))
//      })
//      .catch(error => {
//        console.log('error', error)
//        this.errors1=true
//      this.loading = false;
//      });
      
    this.infoUser = JSON.parse(localStorage.getItem("infoUser"))
  },

  methods: {
    tchat(art, sender) {
      localStorage.setItem("smsRecieve", JSON.stringify(sender))
      localStorage.setItem("art", JSON.stringify(art))
      window.location.href = "/chatArticles"
    },
    makePayment() {
      this.$launchFlutterwave({
        tx_ref: Date.now(),
        amount: this.total,
        currency: "XAF",
        payment_options: "card,mobilemoney,ussd",
        customer: {
          email: localStorage.getItem('email'),
          phonenumber: localStorage.getItem('tel'),
          name: localStorage.getItem('firstName') + " " + localStorage.getItem('lastName'),
        },
        callback: function (data) {
          // specified callback function
          console.log(data);
        },
        customizations: {
          title: "DGA Expreess",
          description: "Courier Service Payment",
          logo: "https://assets.piedpiper.com/logo.png",
        },
      });
    },
    view(item) {
      this.sortCart = "art"
      this.article = item
      var requestOptions5 = {
        method: 'GET',
        redirect: 'follow'
      };

      fetch("http://46.105.36.240:3000/article/paths/" + item.id, requestOptions5)
        .then(response => response.text())
        .then(result => {
          this.path = JSON.parse(result)
        })
        .catch(error => console.log('error', error));
    },
    checkIfIsLogged() {
      let token = localStorage.getItem('access-token')
      //localStorage.getItem('access-token')
      if (token) {
        return true
      } else {
        return false
      }
    },
    signup() {
      let newUser = {
        firstName: this.firstName,
        lastName: this.lastName,
        pseudo: this.pseudo,
        email: this.email,
        password: this.password
      }
      axios.post('http://46.105.36.240:3000/signup', newUser)
      {
        this.$router.push('/');
      }
    },
    onSubmit(event) {
      this.loading = true
      event.preventDefault()
      var axios = require('axios');


      var qs = require('qs');
      var data = qs.stringify({
        'useremail': this.useremail,
        'password': this.password
      });
      var config = {
        method: 'post',
        url: 'http://46.105.36.240:3000/login',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: data
      };

      axios(config)
        .then(function (response) {

          Swal.fire({
            icon: 'success',
            title: ' Succesfully Login!',
            showConfirmButton: false,
            timer: 1500
          })
          window.location.href = "/"
          //const accesstoken = Object.values(temp)[0];
          // const naccesstoken = Object.values(accesstoken)[1.19];
          const temp = response.data;
          const refreshtoken = Object.values(temp)[0];
          const accesstoken = Object.values(temp)[1];
          console.log(JSON.stringify(accesstoken));
          console.log(JSON.stringify(refreshtoken));

          localStorage.setItem('refresh-token', refreshtoken);
          localStorage.setItem('access-token', accesstoken);
          this.$bus.$emit('logged', 'User logged');


        })
        .catch(function (error) {
          if (error.response.status === 500) {
            Swal.fire(
              'Login Failed!',
              'Please Check Your Credentials!.',
              'error'
            )
          } if (error.response.status === 401) {
            Swal.fire(
              'Login Failed!',
              'User Does Not Exist!.',
              'error'
            )
          } if (error.response.status === 404) {
            Swal.fire(
              'Failed!',
              'Something Went Wrong!.',
              'error'
            )
          }
          console.log(error);
        });
    },
    sendMessage(item) {
      localStorage.setItem("art", JSON.stringify(item));
      window.location.href = "/chatArticles"
      localStorage.setItem("smsRecieve", JSON.stringify(item.user))
    },
    addToCard(item) {
      for (let i = 0; i < this.basket.length; i++) {
        if (item == this.basket[i]) {
          Swal.fire(
            'Warning!',
            'this item is already in your cart !',
            'warning'
          )
          return
        }
      }
      this.basket.push(item)
      this.quantities.push("1")
      this.total += item.price
      localStorage.setItem("basket", JSON.stringify([this.basket, this.quantities]))

    },
    viewBasket() {
      this.sortCart = "basket"
    },
    buy() {
      console.log(this.total);
    },
    remov(idx) {
      this.basket.splice(idx, 1)
      this.quantities.splice(idx, 1)
      this.total = 0
      for (let i = 0; i < this.basket.length; i++) {
        this.total += this.basket[i].price * this.quantities[i]
      }
      localStorage.setItem("basket", JSON.stringify([this.basket, this.quantities]))
    },
    newTotal() {
      this.total = 0
      for (let i = 0; i < this.basket.length; i++) {
        this.total += this.basket[i].price * this.quantities[i]
      }
    }
  }
};
</script>
<style>
.imgSlide {
  height: 130px;
}

.art-title {
  font-size: 16px;
}

.art-0 {
  font-size: 15px;
}

.text-art {
  font-size: 15px;
}

.panier {
  position: fixed;
  bottom: 5px;
  left: 5px;
  z-index: 100;
}

.h6 {
  font-size: 18px;
  font-weight: 600;
}

.my-img0 {
  width: 100%;
  height: 100%;
}

.my-img {
  width: 100%;
  height: 300px;
}


.contact-item .icon {
  display: block;
  font-size: 48px;
  color: #5cc9df;
  text-shadow: -2px 2px 0 rgba(0, 0, 0, 0.1);
  -webkit-transition: all .3s ease-out;
  transition: all .3s ease-out;
}

.contact-item .icon:hover {
  color: #5cc9df;
  -webkit-transform: scale(1.3) translateY(-10px);
  transform: scale(1.3) translateY(-10px);
}

.ma-cart {
  overflow: hidden;
}

.bl_form input {
  background: rgba(255, 255, 255, 0.10);
  box-shadow: 0 4px 0px rgba(0, 0, 0, 0.2);
  border: none;
  color: white;
  border-radius: 5px;
  font-size: 16px;
  outline: none;
}

.lb_wrap .lb_label.top,
.lb_wrap .lb_label.bottom {
  left: 66px !important;
}

.lb_wrap .lb_label.left {
  left: 0;
}

.lb_label {
  font-size: 18px;
  font-weight: 400;
  color: rgb(0, 0, 0);
}

.no-placeholder .lb_label {
  display: none;
}

.lb_label.active {
  color: #aaa;
}

#Highlighted-form .form-group label {
  display: none;
  font-size: 18px;
  font-weight: 100;
  text-transform: uppercase;
}

#Highlighted-form.no-placeholder .form-group label {
  display: block;
}

#Highlighted-form .controls {
  padding: 0;
  margin-top: 10px;
}

#Highlighted-form.no-placeholder .controls {
  margin-top: 0;
}

#Highlighted-form .form-control {
  display: inline;
  width: 400px;
  background: #fff;
  border: none;
  border-radius: 5px;
  outline: none;
  box-shadow: 0 4px 0 rgba(0, 0, 0, 0.05);
  height: 48px;
  font-size: 18px;
  color: rgb(0, 0, 0);
  font-weight: 400;
  padding-left: 54px;
}

#Highlighted-form .form-group.half-width {
  width: 40%;
  float: left;
}

#Highlighted-form .form-group {
  position: relative;
}

#Highlighted-form .form-group [class*=fa] {
  display: block;
  width: 45px;
  position: absolute;
  top: 0;
  left: 5px;
  margin-top: 25px;
  color: rgb(255, 115, 0);
  font-size: 24px;
  line-height: 52px;
  text-align: center;
  font-weight: 300;
  -webkit-transition: color .3s ease-out;
  transition: color .3s ease-out;
}

#Highlighted-form .form-group [class*=fa].active {
  color: #ccc;
}

#Highlighted-form.no-placeholder .form-group [class*=fa] {
  top: 10px;
}

#Highlighted-form textarea.form-control {
  height: 100px;
  width: 400px;
  min-width: 100%;
  font-size: 18px;
  font-weight: 400;
  line-height: 24px;
  padding-top: 14px;
  vertical-align: top;
}

#Highlighted-form .form-control:focus {
  outline: none;
  box-shadow: 0 4px 0 rgba(0, 0, 0, 0.05);
}

#Highlighted-form .error-message {
  padding: 5px 0;
  position: absolute;
  top: -35px;
  right: 0;
  font-size: 15px;
  line-height: 24px;
  font-weight: 400;
  color: #ff3345;
  z-index: 10;
}

#Highlighted-form.no-placeholder .error-message {
  top: 0;
}
body {
	background-color: var(--white);
	background: url("https://image.shutterstock.com/shutterstock/photos/1912682356/display_1500/stock-photo-phone-and-basket-hologram-online-shopping-online-store-application-in-a-smartphone-digital-1912682356.jpg");
	background-attachment: fixed;
	background-position: center;
	background-repeat: no-repeat;
	background-size: cover;
	display: grid;
	height: 100vh;

opacity: 3.7;

    
}
</style>