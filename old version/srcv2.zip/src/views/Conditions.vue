    <template>
    <div>
        <lognav />
        <div class="about">
            <div class="head">
                <span>CONDITION GENERAL D'UTILISATION DES PLATEFORMES
                    DGA-EXPRESS</span><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span>TERMES & CONDITIONS</span>
            </div>
            <div class="body">
                <div style="margin-bottom:30px;">
                    <span class="title">AVANT PROPOS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous etes prié de lire attentivement les
                        conditions générales d'utilisation de cette plateforme <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ces dernières contiennent des informations
                        concernant vos droits, obligations et recours légaux. En accédant à la Plateforme DGA-EXPRESS
                        ainsi qu'a son application mobile, vous acceptez d'être lié par ses normes d'utilisations et
                        vous y conformer. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En outre, les présentes Conditions constituent
                        un accord juridique contraignant qui vous lie à DGA-EXPRESS (tel que défini ci-dessous) et qui
                        régit votre accès au site DGA-EXPRESS ainsi qu'à son application , y compris ses sous-domaines (
                        plateformes E-commerce )
                        et tous les autres sites par le biais desquels DGA-EXPRESS fournit les services . nos
                        applications pour mobiles, tablettes , smartphones et les interfaces de programme d'application
                        , ainsi que tous les services associés . Le Site, l'Application et les Services DGA-EXPRESS sont
                        collectivement désignés dans
                        ses différentes plateformes. <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « DGA-EXPRESS » dont le siège social est situé à la rue d'arquet 64,5000 Namur immatriculé...
                        Disposant un points de relais dans la ville de bruxelle à l'adress rue des tanneurs 130 , 1000
                        bruxelles .
                        La manière dont nous collectons et utilisons des données à caractère personnel en lien avec
                        votre accès à nos Plateformes et votre utilisation de ladite Plateforme est décrite dans notre
                        Charte Cookies.
                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">1. OBJET</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;La Plateforme est une place de marché en ligne,
                        un espace interactif d'échanges personnalisés, facilitant la mise en relation des différents
                        acteurs de l'industrie du voyage d'une part et un espace E-commerce d'autre part . Cette
                        Plateforme a pour objectif principal de participer à la réduction des coûts lors des voyages en
                        maximisant le gain potentiel pour une économie solidaire de partage, elle offre également des
                        possibiltés d'achats et de ventes des articles de prémières necessités pouvant faire office de
                        cadeaux. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Les présentes Conditions s'appliquent aux
                        services proposés sur la Plateforme et tout particulièrement sur le site et l'application
                        www.DGA-EXPRESS.com Il s'agit de manière non exhaustive, des services d'envoi de colis, de
                        courriers et/ou de bagages (ci-après ensemble « Bagages »), de la mise en relation d'Expéditeurs
                        et de Voyageurs dans le stricte respect des règles de transport aérien édictées par les
                        compagnies aériennes, assorti de la collecte d'une Participation aux Frais des Voyageurs au
                        travers de la Plateforme ainsi qu'une plateformes Ecommerce (permettant aux voyageurs ,
                        expediteurs d'offrir un present à leurs proches , de completer leurs bagages et aux tiérces
                        utilisateurs de s'offrir les articles de leurs choix à des moindres prix) d'un système de
                        notation des Voyageurs et commercants <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ainsi, ne sont pas admis au transport aux
                        travers des Plateformes les objets suivants : armes, explosifs, armes et objets coupants,
                        produits combustibles, bouteilles de gaz, thermomètres à mercure, allumettes, briquets ou tout
                        autre petit combustible, cartouches d'imprimantes, batteries à électrolyte, batteries au
                        lithium, produits chimiques exceptionnels du type engrais pesticides et désherbants, produits
                        liquides décapants et tout autre produit ou marchandise considérée comme étant dangereuse et
                        dont le transport est interdit par la compagnie aérienne empruntée. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tout autre produit dont le transport par voie
                        aérienne n'est pas spécifiquement interdit par les règles d'aviation civile et la compagnie
                        aérienne empruntée peut être transporté par le biais des Membres des difeerentes Plateformes
                        (clés, vêtements, boissons, appareils électroniques, etc.). Toute action de connexion,
                        d'inscription et de téléchargement effectuée sur la Plateforme conduit automatiquement à
                        l'acceptation des présentes Conditions et vous permet de recevoir les offres commerciales, les
                        publicités et les newsletters pendant toute la durée de votre adhésion à nos Plateformes ( site
                        et Application mobile) <br>

                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">2. DÉFINITIONS</span>
                    <p>
                        Dans les présentes, <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Annonce » désigne toute publication d'un Voyageur, visant à proposer un service pour le
                        transport
                        colis (vendu au kilogrammes), courriers, ventes des articles (reserver à la plateforme Ecommerce
                        )
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Application » désigne un logicie applicatif dévéloppé pour des appareils mobiles, tablettes et
                        smartphone téléchargeable sur l'App Store et/ou sur Google Play, ainsi que les interfaces des
                        programmes d'application ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Attestation de Remise de Bagages » désigne le contrat par lequel le Voyageur atteste avoir
                        reçu le
                        Bagage, avoir vérifié son contenu et s'engage à en être le Gardien et à le remettre au
                        Destinataire
                        ou dans un point de relais DGA-EXPRESS <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Bagage » désigne, sans que cette liste ne soit exhaustive, le (s) bien (s), colis, courriers,
                        ou
                        tout(t)(s) autre(s) objet(s) réglementé(s) convoyé(s) par le Voyageur et confié(s) à
                        l'Expéditeur ;
                        « CGU » désigne les présentes Conditions Générales d'Utilisation y compris la charte de bonne
                        conduite ci-après ;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Compte » désigne un ensemble des ressources informatiques attribuées à un utilisateur ou à un
                        appareil. Il ne peut etre exploiter qu'en s'enregistrant aupres d'un système à l'aide d'un
                        identifiant et d'un authentifiant tel qu'un mot de passe qui doit être créé pour pouvoir devenir
                        Membre et accéder aux services proposés par la Plateforme sous réserve du respect de certaines
                        conditions ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Destinataire » est la personne indiquée par l'Expéditeur à qui le Voyageur doit remettre en
                        mains
                        propres le bien convoyé, dans le cas où celui-ci n'est pas confisqué en douanes ;
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Envoi » faire partir l'objet via Espace publié par un Expéditeur sur la Plateforme et pour
                        lequel
                        il souhaite expédier des Bagages via un tiers en contrepartie de la Participation aux Frais de
                        ce
                        dernier ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Espace » désigne le nombre de Kg réservé par un Expéditeur à bord d'une ou plusieurs valises
                        d'un
                        Voyageur ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Expéditeur » désigne le Membre ayant accepté la proposition d'expédier ses Bagages par le
                        Voyageur
                        ou, le cas échéant, la personne pour le compte de laquelle un Membre a réservé un Espace ; <br>
                        « Frais de Service » désignent des sommes d'argent correspondant à la commission demandée par
                        DGA-EXPRESS pour la mise en relation, lorsque le Membre de la Plateforme décide de passer par un
                        autre Membre de la Plateforme au travers d'un Trajet avec Réservation, cette commission étant
                        énoncée de manière précise et visible dans l'Annonce et acceptée par l'Expéditeur ; « Gardien »
                        ou «
                        Gardien de la chose » désigne la notion de droit selon laquelle une personne est réputée être
                        gardienne d'une chose lorsqu'elle a, sur cette chose, en l'occurrence ici le Bagage, un pouvoir
                        d'usage, de direction et de contrôle, et qu'en conséquence, qu'elle puisse être considéré comme
                        ayant la responsabilité juridique sur cette chose, ici le Bagage, pendant la durée au courant de
                        laquelle le Bagage est en sa possession, pour tous dommages auquel ce Bagage pourrait être
                        exposé.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Membre » désigne toute personne physique ayant créé un compte sur les Plateformes DGAEXPRESS
                        ;<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Participation aux Frais » est la somme d'argent demandée par le Voyageur et acceptée par
                        l'Expéditeur au titre de sa participation aux frais de déplacement pour un trajet donnéé <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Plateforme » emplacement dédié à recevoir des annonces de voyages et autres « DGA » Darling
                        global
                        African Express . <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « DGA-EXPRESS » plateforme de mise en relation entre particuliers pour l'acheminement des
                        colis/courriers faisant l'objet d'une annonce publiée par un Voyageur pour lequel il accepte de
                        transporter ces colis/courriers en contrepartie de paiements ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Réservation » action qui consiste à retenir une place pour bagage dans l'annonce d'un voyageur
                        (
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Services » l'ensemble des devoirs rendus au moyen de la Plateforme à un Membre tel qu'énoncé
                        plus
                        haut dans les conditions, étant précisé que DGA-EXPRESS n'est pas partie prenante dans un
                        contrat
                        d'envoi de colis ou de marchandises ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Site » plateforme accessible à l'adresse www.DGA EXPRESS.com ou tout autre site par lequel
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        DAGA-EXPRESS fournit ses Services ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Sous-Trajet » Parcours d'un point à un autre ;<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Trajet » désigne le point de depart ( ville -pays ) et le point d'arrivée (destination)
                        faisant
                        l'objet d'une Annonce publiée par un Voyageur sur la Plateforme et pour lequel il accepte de
                        transporter des Bagages de tiers en contrepartie de la Participation aux Frais ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        « Voyageur » est le Membre proposant sur la Plateforme, un certain nombre de Kg pour le
                        transport de
                        marchandises en avion pour un trajet précis . <br>

                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">3. ACCEPTATION ET MODIFICATIONS DES CONDITIONS</span> <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span class="sub-title">3.1. ACCEPTATION DES CONDITIONS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;L'acceptation de nos Conditions vous donne droit à
                        l'inscription et/ou au téléchargement de
                        l'Application à partir de votre téléphone mobile ou via internet de manière gratuite.
                        L'utilisation de la Plateforme est subordonnée à l'acceptation des présentes Conditions. Au
                        moment de la création du compte utilisateur, les Membres acceptent les Conditions en ouvrant
                        l'Application et/ou en cliquant sur le bouton ["Confirmer l'inscription"]. Seule l'acceptation
                        de ces Conditions permet aux Membres d'accéder aux services proposés sur la Plateforme.
                        L'acceptation des présentes Conditions est entière et forme un tout indivisible, et les Membres
                        ne peuvent choisir de voir appliquer une partie des Conditions seulement ou encore formuler des
                        réserves. En acceptant les Conditions, le Membre accepte également la Charte de bonne conduite
                        qui y est annexée. En cas de manquement à l'une des obligations prévues par les présentes,
                        DGA-EXPRESS se réserve la possibilité de supprimer le Compte Utilisateur concerné.
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">3.2. MODIFICATION DES CONDITIONS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DGA-EXPRESS se réserve le droit de modifier à tout moment
                        les Conditions, les fonctionnalités
                        offertes sur la Plateforme ou les règles de fonctionnement de cette dernière. Les modifications
                        prendront effets immédiatement dès la mise en ligne des Conditions, avec mention de la date de
                        mise à jour, que tout utilisateur reconnaît avoir préalablement consultées. Les publications
                        d'Annonces au moyen des Plateformes sont totalement gratuite. La consultation d'Annonce et la
                        mise en relation entre les deux parties en sont de même. Toutefois, DGA-EXPRESS se réserve
                        notamment le droit de prendre une commission, des Frais de Service, à tout moment, qui
                        représentera un pourcentage sur la transaction qui sera effectuée au travers de ses Plateformes,
                        pour les Trajets avec Réservation. DGA-EXPRESS pourra aussi à tout moment proposer des services
                        nouveaux, gratuits ou payants sur la Plateforme.
                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">4. INSCRIPTION À LA PLATEFORME ET CRÉATION DE COMPTE</span><br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span class="sub-title">4.1. CONDITIONS D'INSCRIPTION À LA PLATEFORME</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;L'utilisation de la Plateforme est réservée aux personnes
                        physiques âgées d'au moins dix-huit (18) ans révolus à la date d'utilisation. Toute inscription
                        sur la Plateforme par une personne physique âgée de moins de (dix-huit) 18 ans est strictement
                        interdite. En accédant, ou en vous inscrivant sur la Plateforme, vous déclarez et gara ntissez
                        avoir 18 ans ou plus.
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">4.2. CRÉATION DE COMPTE</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chaque Membre doit au préalable créer un Compte, en
                        fournissant des données personnelles le concernant, indispensables au bon fonctionnement du
                        service de mise en relation des personnes (notamment nom, prénom, civilité, numéro de téléphone
                        et adresse e-mail valides, adress de residence, preuve de reservation, piéce d'identité :
                        CNI,passeport ). Nous ne pourrons en aucun cas être tenue responsable des informations qui
                        pourraient être erronées ou frauduleuses communiquées par les Membres. Le Membre s'engage à ne
                        pas créer ou utiliser d'autres comptes que celui initialement créé, que ce soit sous sa propre
                        identité ou celle des tiers. Toute dérogation à cette règle devra faire l'objet d'une demande
                        explicite de la part du Membre et d'une autorisation express et spécifique de Notre part. Le
                        fait de créer ou utiliser de nouveaux comptes sous sa propre identité ou celle de tiers sans en
                        avoir demandé et obtenu l'autorisation pourra entraîner non seulment une poursuite judiciaire ,
                        mais aussi la suspension immédiate des comptes du Membre et de tous les services associés. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Par ailleurs, il est permis de consulter les Annonces même si vous n'êtes pas inscrit sur la
                        Plateforme. En revanche, vous ne pouvez ni publier une Annonce ni réserver un Espace sans avoir,
                        au préalable, créé un Compte et être devenu Membre. Pour créer votre Compte, vous pouvez : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-plane"></i> soit remplir l'ensemble des champs obligatoires figurant sur le
                        formulaire d'inscription ;telecharger tous les documents demandés. La verification de compte est
                        obligatoire par une photo d'identification . le compte ne sera en aucun cas créer si tous les
                        informations démandées ne sont pas renseignées . <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-plane"></i> soit vous connecter, via notre Plateforme, à votre compte Facebook
                        (ci-après, votre « Compte Facebook »). En utilisant une telle fonctionnalité, vous comprenez que
                        Nous aurons accès, publierons sur la Plateforme et conserverons certaines informations de votre
                        Compte Facebook. Vous pouvez à tout moment supprimer le lien entre votre Compte et votre Compte
                        Facebook par l'intermédiaire de la rubrique « Vérifications » de votre profil. Si vous souhaitez
                        en savoir plus sur l'utilisation de vos données dans le cadre de votre Compte Facebook, nous
                        vous invitons à consulter notre politique de confidentialité et celle de Facebook. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        A l'occasion de la création de votre Compte, et ce, quelle que soit la méthode choisie pour ce
                        faire, vous vous engagez à fournir des informations personnelles exactes et conformes à la
                        réalité et à les mettre à jour, par l'intermédiaire de votre profil ou en en avertissant
                        DGA-EXPRESS, afin d'en garantir la pertinence et l'exactitude tout au long de votre relation
                        contractuelle avec Nous. En cas d'inscription par email, vous vous engagez à garder secret le
                        mot de passe choisi lors de la création de votre Compte et à ne le communiquer à personne. En
                        cas de perte ou divulgation de votre mot de passe, vous vous engagez à en informer sans délai
                        DGA-EXPRESS, qui vous permettra alors de réinitialiser votre mot de passe. Vous êtes seul
                        responsable de l'utilisation faite de votre Compte par un tiers, tant que vous n'avez pas
                        expressément notifié DGA-EXPRESS de la perte, de l'utilisation frauduleuse par un tiers et/ou de
                        la divulgation de votre mot de passe à un tiers. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Vous vous engagez à ne pas créer ou utiliser, sous votre
                        propre identité ou celle d'un tiers,
                        d'autres Comptes que celui initialement créé. <br>

                    </p>
                    <span class="sub-title" style="margin-top: 20px;">4.3. VÉRIFICATION</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nous nous réservons le droit, à des fins de transparence,
                        d'amélioration de la confiance, ou de prévention ou détection des fraudes, de mettre en place un
                        système de vérification de certaines des informations que vous fournissez sur votre profil.
                        C'est notamment le cas lorsque vous renseignez votre numéro de téléphone ou vous fournissez une
                        pièce d'identité. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez et acceptez que toute référence sur la
                        Plateforme à des informations dites « vérifiées » ou tout terme similaire signifie uniquement
                        qu'un Membre a réussi avec succès la procédure de vérification existante sur la Plateforme afin
                        de fournir davantage d'informations sur le Membre avec lequel vous envisagez une expédition.
                        Nous ne garantissons ni la véracité, ni la fiabilité, ni la validité d'une information ayant
                        fait l'objet de la procédure de vérification.

                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">5. UTILISATION DES SERVICES</span><br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span class="sub-title">5.1. UTILISATION À TITRE NON PROFESSIONNEL ET NON COMMERCIAL POUR LES
                        PARTICULIERS </span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous vous engagez à n'utiliser les Services et la Plateforme
                        que pour être mis en relation, à titre non professionnel et non commercial, avec des personnes
                        souhaitant réserver un Espace sur votre Trajet avec vous. Nous ne pourrons, en aucun cas, être
                        tenus responsables d'une utilisation à titre professionnel ou commercial de la Plateforme. Nous
                        considérons, de manière non exhaustive, comme activité professionnelle toute activité sur la
                        Plateforme qui, par la nature des services proposés, leur fréquence ou le nombre de colis
                        transportés, entraînerait une situation de bénéfice pour le Voyageur. Seul l'option E-COMMERCE
                        de cette plateformes est reconnu à titre commercial et professionnel . <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En tant que Voyageur, vous vous engagez à ne pas demander
                        une Participation supérieure aux frais que vous supportez réellement et susceptible de vous
                        faire générer un bénéfice, étant précisé que s'agissant d'un partage de frais, vous devez
                        également, en tant que Voyageur, supporter votre part des coûts afférents au Trajet. Vous êtes
                        seul responsable d'effectuer le calcul des frais que vous supportez pour le Trajet, et de vous
                        assurer que le montant demandé à vos Expéditeurs n'excède pas les frais que vous supportez
                        réellement (en excluant votre part de Participation aux Frais). <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DGA-EXPRESS se réserve également la possibilité de suspendre
                        votre Compte, limiter votre accès aux Services ou résilier votre souscription aux présentes
                        Conditions en cas d'activité de votre part sur la Plateforme, qui, du fait de la nature des
                        trajets proposés, de leur fréquence, du nombre d'Espaces proposés à la réservation ou du montant
                        de la Participation aux Frais demandée, entraînerait une situation de bénéfice pour vous ou pour
                        quelque raison que ce soit faisant suspecter à DGA-express que vous générez un bénéfice sur la
                        Plateforme. <br>

                    </p>
                    <span class="sub-title" style="margin-top: 20px;">5.2. LE SERVICE</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;La Plateforme est un service de mise en relation, par lequel
                        l'Expéditeur souhaitant effectuer un Envoi contacte le Voyageur pour fixer un lieu de rencontre
                        pour la remise du Bagage à envoyer et les éventuelles conditions d'envois (volume ou taille des
                        Bagages transportés, nombre de Kg disponibles, délai de livraison, point de livraison, etc.).
                        <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Pour la belgique et le cameroun tous les colis passer ont dans point de relais DGA-EXPRESS et le
                        voyageur pourront soient passer reuperer le colis avant son voyage ou alors se faire livré à
                        domicile contre des frais imposés par DGA-Express. Une fois au cameroun ou en belgique tous les
                        bagages doivent etre deposés dans les points de relais le plus proche pour distribution , les
                        voyageurs ne pourront etre ré numérer que si les destinataires recoivent leurs colis ou si ce
                        dernier deposer le colis dans un point de relais DGA-EXPRESS. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Lors de la remise du ou des Bagage(s), les Expéditeurs et Voyageurs concernés consentent aux
                        termes de l'Attestation de Remise de Bagages produite lors de chaque Confirmation de Réservation
                        et dont le modèle est téléchargeable dans le mail de confirmation de reservation . Par ailleurs,
                        la Plateforme met à la disposition de ses Membres des moyens sécurisés de paiement et se réserve
                        le droit de percevoir une commission, appelée Frais de Service, pour les Trajets avec
                        Réservation, à charge pour Nous de reverser la somme au Voyageur une fois que le Destinataire
                        confirmera avoir reçu le Bagage. Les annulations de dernières minutes, le paiement des Frais de
                        Participation, sont alors supervisées par Nous. Pour autant, Nos Membres souscrivant aux Trajets
                        avec Réservation restent responsables, dans la mesure des dispositions énoncées à l'article 7.1
                        ci-dessous, dans certains cas d'annulation, pour lesquels DGA-EXPRESS n'est nullement
                        responsable. <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        De la même manière, les Membres demeurent responsables des risques liés au transport du ou des
                        Bagage(s), notamment s'agissant du contenu du Bagage, de la perte du Bagage et de la remise du
                        Bagage au Destinataire sauf si les bagages ont été deposé dans les points de relais DGA-EXPRESS
                        pour distribution. <br>
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">5.3. PUBLICATION DES ANNONCES</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; En tant que Membre, et sous réserve que vous remplissiez
                        les conditions ci-dessous, vous pouvez créer et publier des Annonces sur la Plateforme en
                        indiquant des informations quant au Trajet que vous comptez effectuer (dates/heures et lieux de
                        départ et d'arrivée, nombre de Kg mis à disposition, options proposées, montant de la
                        Participation aux Frais, compagnie de voyage etc.). Lors de la publication de votre Annonce,
                        vous pouvez indiquer des villes étapes, dans lesquelles vous acceptez de vous arrêter pour
                        prendre ou déposer des Bagages. Les tronçons du Trajet entre ces villes étapes ou entre l'une de
                        ces villes étapes et le point de départ ou d'arrivée du Trajet constituent des « Sous-Trajets ».
                        <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Vous n'êtes autorisé à publier une Annonce que si vous remplissez l'ensemble des conditions
                        suivantes : <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous êtes titulaire d'un titre de transport
                        valide (billet d'avion, tickets de train...) ; <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous ne proposez des Annonces que pour des
                        Trajets dont l'acquisition du titre de transport a été faite par des moyens licites par
                        vous-même ou par un tiers que vous connaissez personnellement ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous êtes et demeurez le Voyageur, objet de
                        l'Annonce ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous n'avez aucune contre-indication ou
                        incapacité médicale à voyager ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> La compagnie de transport que vous comptez
                        utiliser n'est pas interdite d'exploitation ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous ne comptez pas publier une autre Annonce
                        pour le même Trajet sur la Plateforme; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous n'offrez pas plus d'Espace que celle
                        disponible dans votre valise ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous utilisez une valise en parfait état de
                        fonctionnement, qui ne présente aucun danger ou risque de dommages pour les Bagages des
                        Expéditeurs ; <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class="fa fa-minus" aria-hidden="true"></i> Vous acceptez d'assumer la responsabilité de
                        Gardien de la chose pour le compte de l'Expéditeur. A cet effet, vous êtes responsable du Bagage
                        pendant la durée du Trajet et vous vous engagez à remettre ledit Bagage en l'état, à l'arrivée
                        du Trajet au Destinataire, et ce moyennant Participation de l'Expéditeur aux Frais de votre
                        voyage. <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Vous reconnaissez être le seul responsable du contenu de l'Annonce que vous publiez sur la
                        Plateforme. En conséquence, vous déclarez et garantissez l'exactitude et la véracité de toute
                        information contenue dans votre Annonce et vous engagez à effectuer le Trajet selon les
                        modalités décrites dans votre Annonce. <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Sous réserve que votre Annonce soit conforme aux CGU, elle sera publiée sur la Plateforme et
                        donc visible des Membres et de tous visiteurs, même non Membre, effectuant une recherche sur la
                        Plateforme. DGA-EXPRESS se réserve la possibilité, à sa seule discrétion et sans préavis, de ne
                        pas publier ou retirer, à tout moment, toute Annonce qui ne serait pas conforme aux présentes
                        Conditions ou qu'elle considérerait comme préjudiciable à son image, celle de la Plateforme ou
                        celle des Services. <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Vous reconnaissez et acceptez que les critères pris en compte dans le classement et l'ordre
                        d'affichage de votre Annonce parmi les autres Annonces relèvent de la seule politique de
                        DGAExpress.
                    </p>
                    <span class="sub-title" style="margin-top: 20px;"> 5.4.VALIDATION DE L'ANNONCE</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;La validation de l'information par le client, sur la
                        Plateforme d'une publication ou d'une recherche d'Annonce n'est effective que, lorsque les deux
                        acteurs auront rempli toutes les informations nécessaires à savoir : pays et ville de
                        destination, dates de départ et d'arrivée, le moyen de transport emprunté, preuve de reservation
                        (billet d'avion ), pièce d'identité ( passeport , cni), le nombre de Kg libres ou à céder ainsi
                        que les prix y afférents. Toutefois, nous déclinons toute responsabilité subséquente des aléas
                        qui pourraient survenir lors des rencontres entre clients (arrivées tardives aux lieux de
                        rendez-vous, oubli d'entrer en contact, etc.).
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">5.5. DURÉE DE L'ANNONCE SUR LA PLATEFORME</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;La durée de l'Annonce sur la Plateforme est de trente (30)
                        jours à partir de la date de sa mise en ligne sur la plateforme. A l'expiration de celle-ci,
                        cette annonce est automatiquement déclassée et ne pourra donc plus figurer sur la Plateforme.
                        Cependant, l'Annonce peut toutefois faire l'objet d'un repositionnement à l'initiative du
                        Voyageur en utilisant son Compte précédemment créé. Le nombre de kilogramme déclarés comme
                        disponible par le voyageur diminura aufur et à mesure que les reservations se feront sur
                        l'annonce. Une fois la totalité de kilo reserver l'annonce sera bloquée automatiquement il ne
                        sera plus possible de faire d'autres reservations .
                    </p>
                    <span class="sub-title" style="margin-top: 20px;"> 5.6. RETRAIT OU ANNULATION DE L'ANNONCE - DELAI
                        DE RÉTRACTATION</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Le retrait ou l'annulation d'une Annonce après publication
                        reste gratuit pendant quarante huit (48) heures à compter de l'heure de sa publication ou de
                        mise en ligne. Au-delà de ces deux (2) heures, elle est assujettie au paiement de la somme de 2
                        euroS, somme d'argent à débiter lors du prochain achat sur la Plateforme. Cependant, en cas
                        d'annulation de vols ou de changement de la date de voyage par le Voyageur, celui-ci se doit
                        d'informer l'Expéditeur de la nouvelle date, et convenir avec lui d'une nouvelle réservation.
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Par ailleurs, le retrait ou l'annulation, sans motif
                        valable, d'une Annonce ayant déjà fait l'objet de réservation d'Espace par un Voyageur est
                        assujetti au paiement de la somme de six (6) euros, somme d'argent à débiter lors du prochain
                        achat sur la Plateforme . En cas de récidive, le Voyageur se verra interdire l'accès à la page
                        pour une période minimale de huit (8) mois.

                    </p>
                    <span class="sub-title" style="margin-top: 20px;"> 5.7. RÉSERVATION D'UN ESPACE</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Les modalités de Réservation d'un Espace dépendent de la
                        nature du Trajet envisagé, DGAExpress ayant mis en place pour certains Trajets un système de
                        réservation en ligne. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En tant que Membre, et sous réserve que vous remplissiez les
                        conditions ci-dessous, vous pouvez réserver un Espace sur une Annonce sur la Plateforme en
                        indiquant des informations quant à l'Envoi que vous souhaitez effectuer (description du contenu,
                        poids, montant de la Participation aux Frais, date limite de réception, options proposées,
                        etc.). <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous n'êtes autorisé à réserver un Espace que si vous
                        remplissez l'ensemble des conditions suivantes : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous ne réservez des
                        Espaces que pour des Envois dont l'acquisition du contenu a été faite par des moyens licites par
                        vous-même ou par un tiers que vous connaissez personnellement <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous ne réservez des
                        Espaces que pour des Envois dont le contenu est licite et le transport non prohibé par les
                        compagnies de transport (cf. réglementation sur le transport aérien des compagnies objet du
                        Trajet visé) ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous êtes et demeurez
                        l'Expéditeur, objet de l'Espace ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous ne comptez pas
                        réserver un autre Espace pour la même Annonce sur la Plateforme ; Vous ne comptez pas changer le
                        contenu décrit dans l'Envoi après validation du Voyageur auteur de l'Annonce ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous vous engagez à
                        bien conditionner vos Bagages de manière à ce qu'ils ne présentent aucun danger ou risque de
                        dommages pour la valise du Voyageur ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous vous engagez à
                        présenter le Contenu de votre Envoi ouvert pour vérification et contrôle par le Voyageur,
                        faciliter en participant pleinement à cet exercice de vérification de conformité, valider que le
                        Voyageur a bien contrôlé et vérifié votre Envoi ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous acceptez de
                        confier la responsabilité de Gardien de la chose au Voyageur pour le Bagage à transporter par ce
                        dernier, et ce jusqu'à la remise du dit Bagage au Destinataire ( pour tout autres destinations)
                        ou dans un point de relais DGA ( uniquement applicable en belgique et au cameroun) , dans la
                        ville de destination du Voyageur, à son arrivée du Trajet, moyennant votre Participation aux
                        Frais de son voyage. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous acceptez
                        également fournir les informations sur vos piéces d'identitées ( CNI, passeport ), en cas de
                        constat d'objets ou produits illicites ( stupéfiants) dissimulés dans vos bagages vous serrez
                        tenue pour seul responsable et ferez l'objet des poursuites judiciaires. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez être le seul responsable du contenu de
                        l'Espace que vous publiez sur la Plateforme. En conséquence, vous déclarez et garantissez
                        l'exactitude et la véracité de toute information contenue dans votre Espace et vous engagez à
                        effectuer l'Envoi selon les modalités décrites dans votre Espace. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sous réserve que votre Espace soit conforme aux Conditions,
                        elle sera publiée sur l'Annonce choisie et donc visible du Voyageur. Nous nous réservons la
                        possibilité, à notre seule discrétion et sans préavis, de ne pas publier ou retirer, à tout
                        moment, tout Espace qui ne serait pas conforme aux Conditions ou qu'elle considérerait comme
                        préjudiciable à son image, celle de la Plateforme ou celle des Services. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez et acceptez que les critères pris en
                        compte dans le classement et l'ordre d'affichage de votre Espace parmi les autres Espaces
                        relèvent de la seule politique de DGAExpress <br><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.7.1. Trajet Réservé
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nous avons mis en place un système de réservation d'Espaces
                        en ligne pour les Trajets proposés sur la Plateforme (les « Trajets avec Réservation »). <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;L'éligibilité d'un Trajet au système de Réservation reste à
                        notre seule décision et nous nous réservons la possibilité de modifier ces conditions à tout
                        moment. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorsqu'un Expéditeur est intéressé par une Annonce
                        bénéficiant de la Réservation, il peut effectuer une demande de Réservation en ligne. Cette
                        demande de Réservation est (i) soit acceptée automatiquement (si le Voyageur a choisi cette
                        option lors de la publication de son Annonce), (ii) soit acceptée manuellement par levoyageur .
                        Au moment de la Réservation, l'Expéditeur procède au paiement en ligne du montant de la
                        Participation renseigné par le voyageur et des Frais de Service afférents, le cas échéant. Après
                        vérification du paiement par DGA-Express et validation de la demande de Réservation par le
                        Voyageur, l'Expéditeur reçoit une confirmation de Réservation . Si vous êtes un Voyageur et que
                        vous avez choisi de gérer vousmêmes les demandes de Réservation lors de la publication de votre
                        Annonce, vous êtes tenu de répondre à toute demande de Réservation dans un délai incompressible
                        de deux heures à compter de la demande de chaque Expéditeur. A défaut, la demande de Réservation
                        expire automatiquement et l'Expéditeur est remboursé de l'intégralité des sommes versées au
                        moment de la demande de Réservation, le cas échéant. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;De plus, dès la Confirmation de Réservation et conformément
                        aux termes de l'Attestation de Remise de Bagages, le Voyageur devient seul responsable du Bagage
                        en sa qualité de Gardien de la Chose transportée. A cet effet, il s'engage à prendre toutes les
                        mesures nécessaires pour s'assurer de la conformité du Bagage à transporter et de sa bonne tenue
                        jusqu'à sa remise entre les mains du Destinataire. DGA-Express n'est garant d'aucune
                        réclamation„ revendication, action ou recours d'un Expéditeur vers le Voyageur et/ou de tout
                        tiers pour le Bagage transporté , sauf si le bagage a été remis à un point de rélais DGA-express
                        au depart ou à l'arrivée . A compter de la Confirmation de la Réservation, nous vous
                        transmettons les coordonnées téléphoniques du Voyageur (si vous êtes Expéditeur) ou de
                        l'Expéditeur (si vous êtes Voyageur), dans le cas où le Membre a donné son accord à la
                        divulgation de son numéro de téléphone. Vous êtes désormais seuls responsables de l'exécution du
                        contrat vous liant à l'autre Membre. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.7.2. Caractère
                        nominatif de la réservation d'Espace et modalités d'utilisation des Services pour le compte d'un
                        tiers <br><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Toute utilisation des Services, que ce soit en qualité
                        d'Expéditeur ou de Voyageur, est nominative. Le Voyageur comme l'Expéditeur doivent correspondre
                        à l'identité communiquée à DGA-express. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Toutefois . www.DGA-express.com permet à ses Membres de
                        réserver un ou plusieurs Espaces pour le compte d'un tiers. Dans ce cas, vous vous engagez à
                        indiquer avec exactitude au Voyageur, au moment de la Réservation, les noms, prénoms, âges et
                        numéros de téléphone de la personne pour le compte de laquelle vous réservez un Espace. Il est
                        strictement interdit de réserver un Espace pour un mineur. En revanche, il est interdit de
                        publier une Annonce pour un Voyageur autre que vous-même. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ainsi donc, les Membres sont admis à réserver un espace pour
                        une Expédition concernant un tiers. Par contre, il est formellement interdit de publier une
                        Annonce de voyage alors qu'on ne voyage pas soit même. Dans cette hypothèse, Nous vous invitons
                        à encourager le véritable Voyageur à créer son compte sur la Plateforme et à publier son voyage
                        à partir de son Compte. <br>
                    </p>
                    <span class="sub-title" style="margin-top: 20px;"> 5.8. SYSTÈME D'AVIS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.8.1. Fonctionnement
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nous vous encourageons fortement à laisser un avis sur un
                        Voyageur (si vous êtes Expéditeur) ou un Expéditeur (si vous êtes Voyageur) avec lequel vous
                        avez réservé un Espace ou pour lequel vous avez transporté un Bagage. En revanche, vous n'êtes
                        pas autorisé à laisser un avis sur un autre Expéditeur, si vous étiez vous-même Expéditeur, ni
                        sur un Voyageur avec lequel vous n'avez pas réservé d'Espace. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Votre avis, ainsi que celui laissé par un autre Membre à
                        votre égard, ne sont visibles et publiés sur la Plateforme qu'après le plus court des délais
                        suivants : (i) immédiatement après que vous ayez, tous les deux, laissé un avis ou (ii) passé un
                        délai de (sept) 7 jours après le premier avis laissé. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous avez la possibilité de répondre à un avis qu'un autre
                        Membre a laissé sur votre profil dans un délai maximum de (sept) 7 jours suivant la publication
                        de l'avis laissé à votre égard. L'avis et votre réponse, le cas échéant, seront publiés sur
                        votre profil. <br><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.8.2. Modération <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez et acceptez que DGA-express se réserve la
                        possibilité de ne pas publier ou supprimer tout avis, toute question, tout commentaire ou toute
                        réponse dont il jugerait le contenu contraire aux présentes Conditions. <br><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.8.3. Seuil <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DGA-EXPRESS se réserve la possibilité de suspendre votre
                        Compte, limiter vos accès aux Services ou résilier vos souscription aux présentes Conditions
                        dans le cas où : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- (i) vous avez reçu au
                        moins trois (3) avis mauvaises <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- (ii) la moyenne des
                        avis que vous avez reçus est égale ou inférieure à deux sur cinq (2/5).

                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">6. CONDITIONS FINANCIÈRES</span> <br>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;L'accès et l'inscription à la Plateforme, de même que la
                        recherche, la consultation et la publication d'Annonces sont gratuites. En revanche, tout achat
                        et/ou toute Réservation effectuée sur la Plateforme pour les Trajets Réservés sont payants dans
                        les conditions décrites cidessous.
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">6.1. PARTICIPATION AUX FRAIS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Le montant de la Participation aux Fret est déterminé par
                        vous, en tant que Voyageur, sous votre seule responsabilité. Il est strictement interdit de
                        tirer le moindre bénéfice du fait de l'utilisation de notre Plateforme. Par conséquent, vous
                        vous engagez à limiter le montant de la Participation que vous demandez à vos Expéditeurs aux
                        frais que vous supportez réellement pour effectuer le Trajet. A défaut, vous supporterez seul
                        les risques de requalification de l'opération effectuée par l'intermédiaire de la Plateforme.
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorsque vous publiez une Annonce, DGA-Express vous suggère
                        un montant de Participation aux Frais qui tient compte notamment de la nature du Trajet, du
                        moyen de transport et de la distance parcourue. Ce montant est purement indicatif et il vous
                        appartient de le modifier à la hausse ou à la baisse pour tenir compte des frais que vous
                        supportez réellement sur le Trajet. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Afin d'éviter les abus, DGA-express limite les seuils
                        plafonds et planchers du montant de la Participation aux Frais respectivement entre 200 euros
                        Pour un bagage de 23kg.

                    </p>
                    <span class="sub-title" style="margin-top: 20px;">6.2. FRAIS DE SERVICE</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;La Plateforme offre aux utilisateurs plusieurs moyens de
                        paiement modernes pour le règlement des frais de service. Les utilisateurs ont ainsi la
                        possibilité de régler par : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Carte bancaire (Visa,
                        Master card) ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- PayPal ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Monnaie électronique
                        fournie par les opérateurs de téléphonie mobile. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Le paiement est réputé effectif aussitôt après validation du
                        nombre de kilos ou du montant net à payer. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lors des transactions bancaires, les frais de virement
                        relatifs à l'interconnexion des banques sont à la charge du client. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dans le cadre des Trajets avec Réservation, DGA-express
                        prélève, en contrepartie de l'utilisation de la Plateforme, au moment de la Réservation, une
                        commission correspondant à des frais de service calculés sur la base du montant de la
                        Participation aux Frais. Les modalités de calcul des Frais de Service en vigueur sont d'une part
                        côté expéditeur 4,50 euros plus TVA, et d'autre part côté Voyageur : 13 0/0 de la Participation
                        aux Frais demandé plus TVA. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Les paiements par carte bancaire seront réceptionnés par
                        Stripe, laquelle déduira le montant des Frais de Service avant de remettre le montant de la
                        Participation aux Frais au Voyageur. Les Frais de Service sont perçus par DGA-EXPRESS pour
                        chaque Espace réservé par un Expéditeur. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En ce qui concerne les trajets transfrontaliers, veuillez
                        noter que les modalités de calcul du montant des Frais de Services et de la TVA applicable
                        varient selon le point de départ et/ou d'arrivée du Trajet. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorsque vous utilisez la Plateforme pour des Trajets
                        transfrontaliers ou hors de la belgique , les Frais de Services peuvent être facturés par
                        DGA-express <br>
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">6.3. ARRONDIS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez et acceptez que dga-express peut, à son
                        entière discrétion, arrondir au chiffre inférieur ou supérieur les Frais de Service et la
                        Participation aux Frais.
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">6.4. RÈGLEMENT DES FRAIS DE VENTE AU PROFI DU
                        VOYAGEUR</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Le règlement des frais s'effectuera soixante-douze (72)
                        heures après la confirmation de l'Expéditeur. Le Voyageur recevra son paiement via le modèle de
                        paiement souscrit lors de son inscription sur la Plateforme. Le Voyageur recevra directement la
                        somme réelle déduite du prélèvement automatique des frais de services de notre part. Il en est
                        de meme pour les commercants de la rubrique E-commerce <br><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6.4.1. Règlement des
                        frais de vente au profit du Voyageur <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A la suite du Trajet, les Expéditeurs disposent d'un délai
                        de quarante-huit (48) heures pour présenter une réclamation à dga-express. En l'absence de
                        contestation de leur part dans cette période, DGA considère la confirmation du Trajet comme
                        étant acquise (A compter de cette Confirmation de Réservation, vous disposez, en tant que
                        Voyageur, d'un crédit exigible sur votre <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Compte. Ce crédit correspond au montant total payé par
                        l'Expéditeur au moment de la Confirmation de Réservation diminué des Frais de Service,
                        c'est-à-dire au montant de la Participation aux Frais payée par l'Expéditeur. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Une fois le Bagage acheminé, le Voyageur doit ensuite
                        procéder à la confirmation de livraison tacite ou expresse du Bagage, en remettant ledit Bagage
                        au Destinataire. La confirmation de livraison peu egalement se fait dans les point de relais
                        DGA-express si le voyageur y achemine les colis . La Confirmation de Livraison est dite tacite
                        lorsque les Expéditeurs n'ont pas fait de réclamation dans les quarante-huit (48) heures suivant
                        la réception du Bagage et express lorsque les Expéditeurs ont noté le Voyageur en indiquant que
                        tout s'est bien passé. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Une fois la Confirmation de Livraison validé , vous avez la
                        possibilité, en tant que Voyageur, de Nous donner l'instruction soit de vous verser la
                        Participation aux Frais reçue de l'Expéditeur sur votre compte bancaire (en renseignant sur
                        votre Compte, au préalable, vos coordonnées bancaires), soit sur votre compte Paypal (en
                        renseignant sur votre Compte, au préalable, votre adresse email Paypal) ou tout autre compte
                        admettant des paiements électroniques. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;L'ordre de virement à votre nom sera transmis le premier
                        jour ouvrable suivant votre demande ou à défaut de demande de votre part, le premier jour
                        ouvrable suivant la mise à disposition sur votre profil des sommes concernées (sous réserve que
                        DGA-EXPRESS dispose de vos informations bancaires). <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A l'issue du délai de prescription de trois (3) ans
                        applicable, toute somme non réclamée à DGA sera réputée appartenir à DGA-express. <br> <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6.4.2. Mandat
                        d'Encaissement <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En utilisant la Plateforme en tant que Voyageur, vous Nous
                        confiez un mandat d'encaissement du montant de la Participation aux Frais en votre nom et pour
                        votre compte. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Par conséquent, après acceptation manuelle ou automatique de
                        la Réservation, DGA-express encaisse la totalité de la somme versée par l'Expéditeur (Frais de
                        Service et Participation aux Frais). <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Les Participations aux Frais reçues par DGA-EXPRESS sont
                        déposées sur un compte dédié au paiement des Voyageurs. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez et acceptez qu'aucune des sommes perçues
                        par DGA-express au nom et pour le compte du Voyageur n'emporte droit à intérêts. Vous acceptez
                        de répondre avec exigences à toute demande de dga-express et plus généralement de toute autorité
                        administrative ou judiciaire compétente en particulier en matière de prévention ou de lutte
                        contre le blanchiment. Notamment, vous acceptez de fournir, sur simple demande, tout
                        justificatif d'adresse et/ou d'identité utile. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En l'absence de réponse de votre part à ces demandes,
                        dga-express pourra prendre toute mesure qui lui semblera appropriée notamment le gel des sommes
                        versées et/ou la suspension de votre Compte et/ou la résiliation de la souscription aux
                        présentes Conditions.
                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">7. POLITIQUE D'ANNULATION</span> <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span class="sub-title">7.1. MODALITÉS DE REMBOURSEMENT EN CAS D'ANNULATION</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nos Trajets font l'objet de la présente politique
                        d'annulation. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DGA-express apprécie à sa seule discrétion, sur la base des
                        éléments à sa disposition, la légitimité des demandes de remboursement qu'elle reçoit. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En tout état de cause, en cas d'annulation Voyageur,
                        dga-express vous proposera un autre Voyageur dont la date de départ est comprise entre 0 et 3
                        jours comparé à la date de départ initialement réservée. Dans ce cas aucune demande de
                        remboursement ne sera acceptée. L'annulation d'un Espace d'un Trajet avec Réservation par le
                        Voyageur ou l'Expéditeur après la Confirmation de Réservation est soumise aux stipulations
                        ci-après : <br><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7.1.1. Annulation Imputable au Voyageur <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si le Voyageur annule
                        plus de quarante-huit (48) heures avant l'heure prévue pour le départ telle que mentionnée dans
                        l'Annonce, l'Expéditeur est remboursé du montant intégral de la Participation aux Frais de
                        Voyage et des Frais de Service afférents. Le Voyageur ne reçoit aucune somme de quelque nature
                        que ce soit ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si le Voyageur annule
                        moins de quarante-huit (48) heures ou quarante-huit (48) heures avant l'heure prévue pour le
                        départ, telle que mentionnée dans l'Annonce et plus de vingtquatre (24) heures après la
                        Confirmation de Réservation, l'Expéditeur est remboursé du montant intégral de la Participation
                        aux Frais de Voyage et Frais de Service afférents ; le Voyageur ne reçoit aucune somme de
                        quelque nature que ce soit, au contraire le Voyageur devra acquitter une pénalité correspondante
                        aux Frais de Service qui seront imputés par DGA-EXPRESS sur son prochain Voyage ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si le Voyageur annule
                        moins de vingt-quatre (24) heures ou vingt-quatre (24) heures avant l'heure prévue pour le
                        départ, telle que mentionnée dans l'Annonce et moins de trente (30) minutes après la
                        Confirmation de Réservation, l'Expéditeur est remboursé du montant intégral de la Participation
                        aux Frais de Voyage et des Frais de Service afférents. Le Voyageur ne reçoit aucune somme de
                        quelque nature que ce soit ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si le Voyageur annule
                        moins de vingt-quatre (24) heures ou vingt-quatre (24) heures avant l'heure prévue pour le
                        départ, telle que mentionnée dans l'Annonce et entre trente (30) et une (1) heure après la
                        Confirmation de Réservation, l'Expéditeur est remboursé du montant intégral de la Participation
                        aux Frais de Voyage et Frais de Service afférents ; le Voyageur ne reçoit aucune somme de
                        quelque nature que ce soit, au contraire le Voyageur devra acquitter une pénalité correspondante
                        aux Frais de Service qui seront imputés par DGAEXPRESS sur son prochain Voyage ;<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si le Voyageur annule
                        moins de vingt-quatre (24) heures ou vingt-quatre (24) heures avant l'heure prévue pour le
                        départ, telle que mentionnée dans l'Annonce et plus d'une (1) heure après la Confirmation de
                        Réservation, ou s'il ne se présente pas au lieu de rendez-vous au plus tard dans un délai de
                        trente (30) minutes à compter de l'heure convenue, l'Expéditeur est remboursé du montant
                        intégral de la Participation aux Frais de Voyage et Frais de Service afférents ; Le Voyageur ne
                        reçoit aucune somme de quelque nature que ce soit, au contraire le Voyageur devra acquitter une
                        pénalité qui sera imputée sur son prochain transport ; la pénalité est composée d'une part des
                        Frais de Service qui seront conservés par DGA-EXPRESS et d'autre part 15 euros (10€) de la
                        Participation aux Frais dont la moitié (7,50€) sera reversée à l'Expéditeur. <br><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7.1.2. Annulation Imputable à l'Expéditeur <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si l'Expéditeur annule
                        plus de quarante-huit (48) heures avant l'heure prévue pour le départ telle que mentionnée dans
                        l'Annonce, l'Expéditeur est remboursé du montant intégral de la Participation aux Frais. Les
                        Frais de Service demeurent acquis à DGA-EXPRESS et le Voyageur ne reçoit aucune somme de quelque
                        nature que ce soit ;<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si l'Expéditeur annule
                        moins de quarante-huit (48) heures ou quarante-huit 48 heures avant l'heure prévue pour le
                        départ, telle que mentionnée dans l'Annonce et plus de vingt-quatre (24) heures après la
                        Confirmation de Réservation, l'Expéditeur est remboursé à hauteur de la moitié de la
                        Participation aux Frais versée lors de la Réservation, les Frais de Service demeurent acquis à
                        DGA-EXPRESS et le Voyageur reçoit la moitié (500/0) de la Participation aux Frais ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si l'Expéditeur annule
                        moins de vingt-quatre (24) heures ou vingt-quatre (24) heures avant l'heure prévue pour le
                        départ, comme mentionnée dans l'Annonce et moins de trente (30) minutes après la Confirmation de
                        Réservation l'Expéditeur est remboursé de l'intégralité de la Participation aux Frais. Les Frais
                        de Service demeurent acquis à DGA-Express et le Voyageur ne reçoit aucune somme de quelque
                        nature que ce soit ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si l'Expéditeur annule
                        moins de vingt-quatre (24) heures ou vingt-quatre (24) heures avant l'heure prévue pour le
                        départ, comme mentionnée dans l'Annonce et entre une (1) heure et deux (2) heures après la
                        Confirmation de Réservation, l'Expéditeur est remboursé à hauteur de la moitié de la
                        Participation aux Frais versée lors de la Réservation, les Frais de Service demeurent acquis à
                        DGA-EXPRESS et le Voyageur reçoit la moitié (500/0) de la Participation aux Frais ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Si l'Expéditeur annule
                        moins de vingt-quatre (24) heures ou vingt-quatre (24) heures avant l'heure prévue pour le
                        départ, telle que mentionnée dans l'Annonce et plus de deux (2) heure après la Confirmation de
                        Réservation, ou s'il ne se présente pas au lieu de rendezvous au plus tard dans un délai de
                        quarante-cinq (45) minutes à compter de l'heure convenue, aucun remboursement n'est effectué. Le
                        Voyageur est dédommagé de la Participation aux Frais et les Frais de Services sont conservés par
                        DGA-EXPRESS. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorsque l'annulation intervient à compter d'au moins trois
                        (3) heures avant le départ et du fait de l'Expéditeur, le ou les Espaces annulés par
                        l'Expéditeur sont de plein droit remis à la disposition d'autres Expéditeurs pouvant les
                        réserver en ligne, lesquelles nouvelles Réservations seront soumises aux présentes Conditions.

                    </p>
                    <span class="sub-title" style="margin-top: 20px;">7.2. DROIT DE RÉTRACTION</span>
                    <p>
                        En acceptant les présentes Conditions, vous acceptez expressément que la mise en relation avec
                        un autre Membre soit exécutée avant l'expiration du délai de rétractation fixé à 2 heures après
                        l'édition de l'Annonce ou la Réservation du Trajet. Dès la Confirmation de la Réservation des
                        Trajets, vous ne disposez de la faculté de vous rétracter que dans les conditions énoncées
                        cidessus à l'article 7.1 des présentes Conditions.
                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">8. COMPORTEMENT DES UTILISATEURS DE LA PLATEFORME ET MEMBRES</span> <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span class="sub-title">8.1. ENGAGEMENT DE TOUS LES UTILISATEURS DE LA PLATEFORME</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez être seul responsable du respect de
                        l'ensemble des lois, règlements et obligations applicables à votre utilisation de la Plateforme.
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Par ailleurs, en utilisant la Plateforme et lors des
                        Trajets, vous vous engagez à : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne pas utiliser la
                        Plateforme reserver aux annonces de voyages à des fins professionnelles, commerciales ou
                        lucratives ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne transmettre à
                        DGA-express (notamment lors de la création ou la mise à jour de votre Compte) ou aux autres
                        Membres aucune information erronée, trompeuse, mensongère ou frauduleuse ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne tenir aucun propos,
                        n'avoir aucun comportement ou ne publier sur la Plateforme aucun contenu à caractère
                        diffamatoire, injurieux, obscène, pornographique, vulgaire, offensant, agressif, déplacé,
                        violent, menaçant, harcelant, raciste, xénophobe, à connotation sexuelle, incitant à la haine, à
                        la violence, à la discrimination ou à la haine, encourageant les activités ou l'usage de
                        substances illégales ou, plus généralement, contraires aux finalités de la Plateforme, de nature
                        à porter atteinte aux droits de DGA-express ou d'un tiers ou contraires aux bonnes mœurs ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne pas porter atteinte
                        aux droits et à l'image de DGA-EXPRESS notamment à ses droits de propriété intellectuelle ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne pas ouvrir plus d'un
                        Compte sur la Plateforme et ne pas ouvrir de Compte au nom d'un tiers ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne pas tenter de
                        contourner le système de réservation en ligne de la Plateforme, notamment en tentant de
                        communiquer à un autre Membre vos coordonnées afin de réaliser la réservation en dehors de la
                        Plateforme et ne pas payer les Frais de Service ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne pas contacter un
                        autre Membre, notamment par l'intermédiaire de la Plateforme, à une autre fin que celle de
                        définir les modalités du partage de valises ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ne pas accepter ou
                        effectuer un paiement en dehors de la Plateforme ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous conformer aux présentes Conditions et à la Politique de
                        Confidentialité.

                    </p>
                    <span class="sub-title" style="margin-top: 20px;">8.3. ENGAGEMENT DES EXPÉDITEURS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorsque vous utilisez la Plateforme en tant qu'Expéditeur,
                        vous vous engagez à : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adopter un comportement convenable et responsable au cours
                        de la remise des Bagages au <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voyageur et leur collecte par le Destinataire ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- En cas d'empêchement,
                        en informer sans délai le Voyageur ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Attendre le Voyageur
                        sur le lieu de rencontre convenu au moins 15 minutes au-delà de l'heure convenue ;<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Communiquer à
                        DGA-express ou tout Voyageur qui vous en fait la demande, votre carte d'identité ou tout
                        document de nature à attester de votre identité ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- N'expédier, dans
                        l'Espace réservé, aucun objet, marchandise, substance, animal dont le transport est contraire
                        aux règles, codes, lois et dispositions légales en vigueur au sein des pays de départ, d'arrivée
                        et éventuellement d'escale , <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- En cas de Trajet
                        transfrontalier, disposer et tenir à disposition du Voyageur et de toute autorité qui le
                        solliciterait tout document de nature à justifier de votre identité et de votre faculté à
                        franchir la frontière ;<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous assurez d'être
                        joignable par téléphone par le Voyageur, au numéro enregistré sur votre profil et notamment au
                        point de rendez-vous. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dans le cas où vous auriez procédé à la Réservation d'un ou
                        plusieurs Espaces pour le compte de tiers, vous vous portez fort du respect de celle-ci par ce
                        tiers. DGA-express se réserve la possibilité de suspendre votre Compte, limiter votre accès aux
                        Services ou résilier la souscription aux présentes Conditions, en cas de manquement de la part
                        du tiers pour le compte duquel vous avez réservé un Espace aux présentes Conditions.
                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">9. SUSPENSION DE COMPTES, LIMITATIONS D'ACCÈS ET RÉSILIATION</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous avez la possibilité de mettre fin à votre relation
                        contractuelle avec Nous à tout moment, sans frais et sans motif. Pour cela, il vous suffit de
                        vous rendre dans l'onglet « Fermeture de compte » de votre page Profil. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En cas de non-respect de votre part de tout ou partie des
                        Conditions, vous reconnaissez et acceptez que DGA-express peut à tout moment, sans notification
                        préalable, interrompre ou suspendre, de manière temporaire ou définitive, tout ou partie du
                        Service ou l'accès des Membres à la Plateforme (y compris notamment le Compte Utilisateur) ou
                        pour toute raison objective. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorsque cela est nécessaire, vous serez notifié de la mise
                        en place d'une telle mesure afin de vous permettre de donner des explications à DGA-express.
                        Nous déciderons, à Notre seule discrétion, de lever les mesures mises en place ou non.

                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">10. DONNÉES PERSONNELLES</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dans le cadre de votre utilisation de la Plateforme, Nous
                        pouvons être amenés à collecter et traiter certaines de vos données personnelles. En utilisant
                        la Plateforme et en vous y inscrivant en tant que Membre, vous reconnaissez et acceptez le
                        traitement de vos données personnelles par DGA-express conformément à la loi applicable et aux
                        stipulations de la politique de confidentialité de DGA-express.
                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">11. PROPRIÉTÉ INTELLECTUELLE</span> <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span class="sub-title">11.1. CONTENU PUBLIÉ PAR DGA-EXPRESS</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sous réserve des contenus fournis par ses Membres,
                        dga-express est seule titulaire de l'ensemble des droits de propriété intellectuelle afférents
                        au Service, à la Plateforme, à son contenu (notamment les textes, images, dessins, logos,
                        vidéos, sons, données, graphiques) ainsi qu'aux logiciels et bases de données assurant leur
                        fonctionnement. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nous vous accordons une licence non exclusive, personnelle
                        et non cessible d'utilisation de la Plateforme et des Services, pour votre usage personnel et
                        privé, à titre non commercial et conformément aux finalités de la Plateforme et des Services.
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous vous interdisez toute autre utilisation ou exploitation
                        de la Plateforme et des Services, et de leur contenu sans l'autorisation préalable écrite de
                        DGA-express. Notamment, vous vous interdisez de : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Reproduire, modifier,
                        adapter, distribuer, représenter publiquement, diffuser la Plateforme, les Services et leur
                        contenu, à l'exception de ce qui est expressément autorisé par DGAEXPRESS ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Décompiler, procéder à
                        de l'ingénierie inverse de la Plateforme ou des Services, sous réserve des exceptions prévues
                        par les textes en vigueur ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Extraire ou tenter
                        d'extraire (notamment en utilisant des robots d'aspiration de données ou tout autre outil
                        similaire de collecte de données) une partie substantielle des données de la Plateforme.
                    </p>
                    <span class="sub-title" style="margin-top: 20px;">11.2. CONTENU PUBLIÉ PAR VOUS SUR LA
                        PLATEFORME</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Afin de permettre la fourniture des Services et conformément
                        à la finalité de la Plateforme, vous concédez à DGA-express une licence non exclusive
                        d'utilisation des contenus et données que vous fournissez dans le cadre de votre utilisation des
                        Services . Afin de permettre la diffusion par réseau numérique et selon tout protocole de
                        communication (notamment Internet et réseau mobile), ainsi que la mise à disposition au public
                        du contenu de la Plateforme, vous autorisez DGA-EXPRESS, pour le monde entier et pour toute la
                        durée de votre relation contractuelle avec DGA-express à reproduire, représenter, adapter et
                        traduire votre Contenu Membre de la façon suivante : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous autorisez
                        DGA-expresss à reproduire tout ou partie de votre Contenu Membre sur tout support
                        d'enregistrement numérique, connu ou inconnu à ce jour, et notamment sur tout serveur, disque
                        dur, carte mémoire, ou tout autre support équivalent, en tout format et par tout procédé connu
                        et inconnu à ce jour, dans la mesure nécessaire à toute opération de stockage, sauvegarde,
                        transmission ou téléchargement lié au fonctionnement de la Plateforme et à la fourniture du
                        Service ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Vous autorisez
                        DGA-express à adapter et traduire votre Contenu Membre, ainsi qu'à reproduire ces adaptations
                        sur tout support numérique, actuel ou futur, stipulé au (i) cidessus, dans le but de fournir les
                        Services, notamment en différentes langues. Ce droit comprend notamment la faculté de réaliser,
                        dans le respect de votre droit moral, des modifications de la mise en forme de votre Contenu
                        Membre aux fins de respecter la charte graphique de la Plateforme et/ou de rendre ledit Contenu
                        techniquement compatible en vue de sa publication via la Plateforme.
                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">12. NOTRE RÔLE</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;La Plateforme constitue une plateforme en ligne de mise en
                        relation sur laquelle les Membres peuvent créer et publier des Annonces pour des Trajets à des
                        fins de transport de colis/courriers pour tiers d'une part et d'autre part l'option E-commerce.
                        Ces Annonces peuvent notamment être consultées par les autres Membres pour prendre connaissance
                        des modalités du Trajet et, le cas échéant, réserver directement un Espace sur le Trajet
                        concerné auprès du Membre ayant posté l'annonce sur la Plateforme. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En utilisant la Plateforme et en acceptant les présentes
                        Conditions, vous reconnaissez que DGAexpress n'est partie à aucun accord conclu entre vous et
                        les autres Membres en vue de partager les frais afférents à un Trajet. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En outre, il est expressément établi que nous n'avons aucun
                        contrôle sur le comportement des Membres et des utilisateurs de la Plateforme. Nous ne possédons
                        pas, n'exploitons pas, ne fournissons pas, ne gérons pas les moyens de transport objets des
                        Annonces, ni ne proposons le moindre Trajet sur la Plateforme. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous reconnaissez et acceptez que DGA-EXPRESS ne contrôle ni
                        la validité, ni la véracité, ni la légalité des Annonces, des Espaces et Trajets proposés. En sa
                        qualité d'intermédiaire en transport de Bagages, DGA-EXPRESS ne fournit aucun service de
                        transport et n'agit pas en qualité de transporteur, Notre rôle ne se limitant qu'à faciliter
                        l'accès à des Membres via la Plateforme pour le transport de leurs Bagages entre Expéditeurs et
                        Vendeurs. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Les Membres (Voyageurs ou Expéditeurs) agissent sous leur
                        seule et entière responsabilité. En sa qualité d'intermédiaire, DGA-EXPRESS ne saurait voir sa
                        responsabilité engagée au titre du déroulement effectif d'un Trajet, et notamment du fait : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- D'informations
                        erronées communiquées par le Voyageur, dans son Annonce, ou par tout autre moyen, quant au
                        Trajet et à ses modalités ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- L'annulation ou la
                        modification d'un Trajet par un Membre ; <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Le comportement de ses
                        Membres pendant, avant, ou après le Trajet.

                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">13. NAVIGATION OU UTILISATION DE LA PLATEFORME</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nous nous efforcerons, dans la mesure du possible, de
                        maintenir la Plateforme accessible sept (7) jours sur sept (7) et vingt-quatre (24) heures sur
                        vingt-quatre (24) partout dans le monde au moyen d'une connexion internet avec des mises à jour
                        des informations les plus récentes. Pour continuer sa navigation de manière fluide et avoir
                        l'accès facile à l'information publiée sur la Plateforme, le Membre se doit de faire les choix
                        ci-dessous : Langue de navigation, - Mode de transport : Avion, Autres ;1- Avion : Pour les
                        colis, les plis et les bagages accompagnés, etc... Le nombre de Kg libres pour le cas des
                        Bagages accompagnés ou expédiés par avion. 2- Train :volume d'espace libre pour le transport des
                        Bagages. - Pays, villes de destination ; - Dates de départs et d'arrivées ; - Aéroports ou gares
                        de départs et d'arrivées ; - Compagnie aérienne ; Compagnie ferroviaire. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Néanmoins, l'accès à la Plateforme pourra être
                        temporairement suspendu, sans préavis, en raison d'opérations techniques de maintenance, de
                        migration, de mises à jour ou en raison de pannes ou de contraintes liées au fonctionnement des
                        réseaux. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En outre, DGA-EXPRESS se réserve le droit de modifier ou
                        d'interrompre, à sa seule discrétion, de manière temporaire ou permanente, tout ou partie de
                        l'accès à la Plateforme ou à ses fonctionnalités.

                    </p>
                </div>
                <div style="margin-bottom:30px;">
                    <span class="title">14. DROIT APPLICABLE - LITIGE</span>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Les présentes Conditions sont rédigées en français et
                        soumises à la loi et réglementation française. <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vous pouvez également présenter, vos réclamations relatives
                        à notre Plateforme ou à nos Services, sur la plateforme de résolution des litiges mise en ligne
                        par la Commission Européenne accessible ici. La Commission Européenne se chargera de transmettre
                        votre réclamation aux médiateurs nationaux compétents. Conformément aux règles applicables à la
                        médiation, vous êtes tenus, avant toute demande de médiation, d'avoir fait préalablement part
                        par écrit à DGAEXPRESS de tout litige afin d'obtenir une solution à la miable.

                    </p>
                </div>
            </div>
        </div>
        <footerVue />
    </div>


</template>

<script>
import lognav from '../components/lognav.vue'
import footerVue from "@/components/footer.vue"

export default {
    name: "Home",
    components: {
        lognav,
        footerVue
    },
}
</script>

<style lang="scss">
body {
    background-color: var(--white);
    // background: url("../assets/img/logo.png");
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    backface-visibility: hidden;
    display: grid;
    height: 100vh;
    background-color: #f1f7ff;

    background {
        opacity: 0;
    }
}

.about {
    min-height: 300px;
    width: 100%;

    .head {
        width: 100%;
        padding: 0 0 10px 100px;

        span:nth-child(1) {
            font-size: 20px;
            font-weight: bold;
        }

        span:nth-child(2) {
            font-size: 16px;
            font-weight: 400;
        }

    }

    .body {
        padding: 5px 140px;
        text-align: justify;

    }
}
</style>